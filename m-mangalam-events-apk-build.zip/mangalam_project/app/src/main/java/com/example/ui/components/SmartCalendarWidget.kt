package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.AvailabilitySlot
import com.example.data.model.SlotKey
import com.example.data.model.SlotStatus
import com.example.i18n.AppStrings
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.AvailableGreenBg
import com.example.ui.theme.BookedRed
import com.example.ui.theme.BookedRedBg
import com.example.ui.theme.ElevatedCharcoal
import com.example.ui.theme.HairlineGoldBorder
import com.example.ui.theme.LockedBlue
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.PendingOrange
import com.example.ui.theme.PendingOrangeBg
import com.example.ui.theme.RoyalGold
import java.util.Calendar
import java.util.Locale

data class CalendarDayInfo(
    val dateIso: String,
    val dayOfMonth: Int,
    val isPast: Boolean
)

@Composable
fun SmartCalendarWidget(
    availabilitySlots: List<AvailabilitySlot>,
    currentUserId: String,
    selectedDateIso: String,
    selectedSlotKey: SlotKey?,
    strings: AppStrings,
    vendorManageMode: Boolean = false,
    onDateSelected: (String) -> Unit,
    onSlotSelected: (SlotKey, SlotStatus) -> Unit,
    modifier: Modifier = Modifier
) {
    val todayCal = remember { Calendar.getInstance() }
    var monthOffset by remember { mutableStateOf(0) }

    val displayCal = remember(monthOffset) {
        Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, monthOffset)
        }
    }

    val year = displayCal.get(Calendar.YEAR)
    val month = displayCal.get(Calendar.MONTH)
    val monthTitle = remember(year, month) {
        val names = listOf(
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        )
        "${names[month]} $year"
    }

    val daysInMonth = displayCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = displayCal.get(Calendar.DAY_OF_WEEK) - 1 // Sunday = 0

    val todayIso = remember {
        String.format(
            Locale.US, "%04d-%02d-%02d",
            todayCal.get(Calendar.YEAR),
            todayCal.get(Calendar.MONTH) + 1,
            todayCal.get(Calendar.DAY_OF_MONTH)
        )
    }

    val slotsByDate = remember(availabilitySlots) {
        availabilitySlots.groupBy { it.dateIso }
    }

    fun dayVisualStatus(dateIso: String): SlotStatus {
        val daySlots = slotsByDate[dateIso].orEmpty()
        if (daySlots.isEmpty()) return SlotStatus.AVAILABLE
        val statuses = daySlots.map { SlotStatus.safeValueOf(it.status) }
        return when {
            statuses.count { it == SlotStatus.BOOKED } >= SlotKey.entries.size -> SlotStatus.BOOKED
            statuses.any { it == SlotStatus.BOOKED } -> SlotStatus.BOOKED
            statuses.any { it == SlotStatus.PENDING || it == SlotStatus.LOCKED } -> SlotStatus.PENDING
            statuses.any { it == SlotStatus.BLOCKED } -> SlotStatus.BLOCKED
            else -> SlotStatus.AVAILABLE
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = OnyxCard),
        border = BorderStroke(1.dp, HairlineGoldBorder),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { if (monthOffset > 0) monthOffset-- },
                    enabled = monthOffset > 0
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = "Previous month",
                        tint = if (monthOffset > 0) RoyalGold else MutedChampagne.copy(alpha = 0.3f)
                    )
                }
                Text(
                    text = monthTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = RoyalGold,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = { if (monthOffset < 11) monthOffset++ }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Next month",
                        tint = RoyalGold
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Legend: Green = Available, Red = Booked, Orange = Pending
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CalendarLegendDot(AvailableGreen, strings.availableLabel)
                CalendarLegendDot(BookedRed, strings.bookedLabel)
                CalendarLegendDot(PendingOrange, strings.pendingLabel)
            }

            Spacer(Modifier.height(12.dp))

            // Weekday Headers
            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("Su", "Mo", "Tu", "We", "Th", "Fr", "Sa").forEach { wd ->
                    Text(
                        text = wd,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedChampagne
                    )
                }
            }

            Spacer(Modifier.height(6.dp))

            // Calendar Grid
            val totalCells = firstDayOfWeek + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - firstDayOfWeek + 1
                        if (dayNum in 1..daysInMonth) {
                            val dateIso = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayNum)
                            val isPast = dateIso < todayIso
                            val status = dayVisualStatus(dateIso)
                            val isSelected = dateIso == selectedDateIso

                            val (bg, fg, borderCol) = when {
                                isPast -> Triple(ElevatedCharcoal.copy(alpha = 0.4f), MutedChampagne.copy(alpha = 0.35f), Color.Transparent)
                                status == SlotStatus.BOOKED -> Triple(BookedRedBg, BookedRed, if (isSelected) RoyalGold else BookedRed.copy(alpha = 0.6f))
                                status == SlotStatus.PENDING -> Triple(PendingOrangeBg, PendingOrange, if (isSelected) RoyalGold else PendingOrange.copy(alpha = 0.6f))
                                status == SlotStatus.BLOCKED -> Triple(ElevatedCharcoal, MutedChampagne, if (isSelected) RoyalGold else MutedChampagne.copy(alpha = 0.3f))
                                else -> Triple(AvailableGreenBg, AvailableGreen, if (isSelected) RoyalGold else AvailableGreen.copy(alpha = 0.5f))
                            }

                            val animatedBg by animateColorAsState(bg, label = "dayBg")
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(animatedBg)
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = borderCol,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable(enabled = !isPast) { onDateSelected(dateIso) }
                                    .testTag("calendar_day_$dateIso"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = dayNum.toString(),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isSelected) RoyalGold else fg,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            if (selectedDateIso.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Text(
                    text = "${strings.selectSlotPrompt} ($selectedDateIso)",
                    style = MaterialTheme.typography.titleSmall,
                    color = RoyalGold
                )
                Spacer(Modifier.height(8.dp))

                val daySlots = slotsByDate[selectedDateIso].orEmpty()
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SlotKey.entries.forEach { slotKey ->
                        val slotObj = daySlots.firstOrNull { it.slotKey == slotKey.name }
                        val rawStatus = SlotStatus.safeValueOf(slotObj?.status)
                        val isLockedByMe = rawStatus == SlotStatus.LOCKED && slotObj?.lockedByUserId == currentUserId
                        val isExpiredLock = rawStatus == SlotStatus.LOCKED &&
                            (slotObj?.lockExpiresAt?.seconds ?: 0L) <= (System.currentTimeMillis() / 1000L)
                        val effectiveStatus = if (isExpiredLock) SlotStatus.AVAILABLE else rawStatus
                        val isSelected = selectedSlotKey == slotKey

                        val (bg, accent, statusLabel, icon) = when {
                            effectiveStatus == SlotStatus.BOOKED -> Quad(
                                BookedRedBg, BookedRed, strings.bookedLabel, Icons.Default.Lock
                            )
                            isLockedByMe -> Quad(
                                InfoIndigoCompat, LockedBlue, strings.lockedByYouLabel, Icons.Default.Schedule
                            )
                            effectiveStatus == SlotStatus.PENDING || effectiveStatus == SlotStatus.LOCKED -> Quad(
                                PendingOrangeBg, PendingOrange, strings.pendingLabel, Icons.Default.Schedule
                            )
                            effectiveStatus == SlotStatus.BLOCKED -> Quad(
                                ElevatedCharcoal, MutedChampagne, strings.blockedLabel, Icons.Default.Block
                            )
                            else -> Quad(
                                AvailableGreenBg, AvailableGreen, strings.availableLabel, Icons.Default.CheckCircle
                            )
                        }

                        val canTap = vendorManageMode || effectiveStatus == SlotStatus.AVAILABLE || isLockedByMe

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = canTap) { onSlotSelected(slotKey, effectiveStatus) }
                                .testTag("slot_${slotKey.name}"),
                            color = bg,
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) RoyalGold else accent.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = slotKey.label,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = ObsidianBlackTextCompat
                                    )
                                    Text(
                                        text = slotKey.timeRange,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MutedChampagne
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = statusLabel,
                                        tint = accent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = statusLabel,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = accent
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private val InfoIndigoCompat = Color(0xFF162533)
private val ObsidianBlackTextCompat = Color(0xFFF8F5EE)

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
private fun CalendarLegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MutedChampagne
        )
    }
}
