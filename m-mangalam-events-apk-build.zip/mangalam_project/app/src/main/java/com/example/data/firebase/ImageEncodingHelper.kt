package com.example.data.firebase

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.R
import java.io.ByteArrayOutputStream
import kotlin.math.max

object ImageEncodingHelper {
    private const val MAX_DIM_PX = 420
    private const val MAX_BASE64_CHARS = 140_000

    fun encodePickerUriToBase64(context: Context, uri: Uri): String? {
        return try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val original = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val longest = max(original.width, original.height)
            val scaled = if (longest > MAX_DIM_PX) {
                val ratio = MAX_DIM_PX.toFloat() / longest.toFloat()
                val w = (original.width * ratio).toInt().coerceAtLeast(1)
                val h = (original.height * ratio).toInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(original, w, h, true)
            } else {
                original
            }
            var quality = 72
            var encoded = ""
            while (quality >= 30) {
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
                encoded = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                if (encoded.length <= MAX_BASE64_CHARS) break
                quality -= 12
            }
            if (scaled !== original) scaled.recycle()
            original.recycle()
            if (encoded.length <= MAX_BASE64_CHARS) encoded else null
        } catch (_: Exception) {
            null
        }
    }

    fun decodeBase64ToImageBitmap(base64: String?): ImageBitmap? {
        if (base64.isNullOrBlank()) return null
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    fun drawableResForKey(key: String?): Int = when (key?.lowercase()) {
        "hero" -> R.drawable.img_hero_celebration
        "wedding", "engagement", "mandap" -> R.drawable.img_event_wedding
        "jewellery", "clothes", "attire" -> R.drawable.img_product_jewellery
        "decor", "decorations", "gifts", "shoes", "birthday", "anniversary", "baby shower", "party" ->
            R.drawable.img_product_decor
        else -> R.drawable.img_hero_celebration
    }
}
