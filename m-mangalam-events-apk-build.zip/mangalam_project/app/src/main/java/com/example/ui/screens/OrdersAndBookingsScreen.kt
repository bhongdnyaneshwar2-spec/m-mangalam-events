package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.EventBooking
import com.example.data.model.PaymentRecord
import com.example.data.model.ProductOrder
import com.example.data.model.SlotKey
import com.example.data.model.UiState
import com.example.i18n.AppStrings
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.StatusPill
import com.example.ui.components.UpiPaymentDialog
import com.example.ui.components.formatInr
import com.example.ui.components.mangalamFieldColors
import com.example.ui.theme.BookedRed
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.HairlineGoldBorder
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalGold
import com.example.ui.viewmodel.MarketplaceViewModel

@Composable
fun OrdersAndBookingsScreen(
    viewModel: MarketplaceViewModel,
    strings: AppStrings
) {
    val bookingsState by viewModel.customerBookings.collectAsStateWithLifecycle()
    val ordersState by viewModel.customerOrders.collectAsStateWithLifecycle()
    val payments by viewModel.customerPayments.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var payingBooking by remember { mutableStateOf<EventBooking?>(null) }
    var cancellingBooking by remember { mutableStateOf<EventBooking?>(null) }
    var cancelReason by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = ObsidianBlack,
            contentColor = RoyalGold,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = RoyalGold
                )
            }
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Events") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Orders") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Payments") })
        }

        when (selectedTab) {
            0 -> {
                when (val state = bookingsState) {
                    is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = RoyalGold)
                    }
                    is UiState.Error -> Text(state.message, color = BookedRed, modifier = Modifier.padding(16.dp))
                    is UiState.Success -> {
                        if (state.data.isEmpty()) {
                            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                Text(strings.emptyBookings, color = MutedChampagne)
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(state.data, key = { it.id }) { booking ->
                                    BookingCard(
                                        booking = booking,
                                        strings = strings,
                                        onPayRemaining = { payingBooking = booking },
                                        onCancel = {
                                            cancelReason = ""
                                            cancellingBooking = booking
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                when (val state = ordersState) {
                    is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = RoyalGold)
                    }
                    is UiState.Error -> Text(state.message, color = BookedRed, modifier = Modifier.padding(16.dp))
                    is UiState.Success -> {
                        if (state.data.isEmpty()) {
                            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                Text(strings.emptyOrders, color = MutedChampagne)
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(state.data, key = { it.id }) { order ->
                                    OrderCard(order)
                                }
                            }
                        }
                    }
                }
            }
            else -> {
                if (payments.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No UPI payments or refunds recorded yet.", color = MutedChampagne)
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(payments, key = { it.id }) { pay ->
                            PaymentHistoryCard(pay)
                        }
                    }
                }
            }
        }
    }

    payingBooking?.let { booking ->
        UpiPaymentDialog(
            title = "${strings.payRemaining} • ${booking.serviceTitle}",
            amountInr = booking.remainingAmountInr,
            totalInr = booking.remainingAmountInr,
            allowAdvanceToggle = false,
            advanceAmountInr = booking.remainingAmountInr,
            strings = strings,
            isBusy = isBusy,
            onDismiss = { payingBooking = null },
            onConfirmPayment = { _, upiApp, upiId ->
                viewModel.payRemainingBooking(booking, upiApp, upiId)
                payingBooking = null
            }
        )
    }

    cancellingBooking?.let { booking ->
        AlertDialog(
            onDismissRequest = { cancellingBooking = null },
            containerColor = OnyxCard,
            title = { Text(strings.cancelBooking, color = RoyalGold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Cancelling releases ${booking.eventDateIso} (${SlotKey.safeValueOf(booking.slotKey).label}) back to Available and initiates refund tracking for ${formatInr(booking.paidAmountInr)}.",
                        color = IvoryText,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = cancelReason,
                        onValueChange = { cancelReason = it },
                        label = { Text("Reason for cancellation") },
                        colors = mangalamFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                GoldGradientButton(
                    text = "Confirm Cancellation",
                    isLoading = isBusy,
                    onClick = {
                        viewModel.cancelBooking(booking, cancelReason)
                        cancellingBooking = null
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { cancellingBooking = null }) {
                    Text("Keep Booking", color = MutedChampagne)
                }
            }
        )
    }
}

@Composable
private fun BookingCard(
    booking: EventBooking,
    strings: AppStrings,
    onPayRemaining: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = OnyxCard),
        border = BorderStroke(1.dp, HairlineGoldBorder),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(booking.eventType, style = MaterialTheme.typography.labelLarge, color = RoyalGold)
                StatusPill(booking.status)
            }
            Text(booking.serviceTitle, style = MaterialTheme.typography.titleMedium, color = IvoryText)
            Text(
                "${booking.eventDateIso} • ${SlotKey.safeValueOf(booking.slotKey).label}",
                style = MaterialTheme.typography.bodyMedium,
                color = ChampagneGold
            )
            Text("${booking.vendorName} • ${booking.venueAddress}", style = MaterialTheme.typography.bodyMedium, color = MutedChampagne)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Paid: ${formatInr(booking.paidAmountInr)} / ${formatInr(booking.totalAmountInr)}", style = MaterialTheme.typography.labelLarge, color = IvoryText)
                    if (booking.remainingAmountInr > 0 && booking.status != "CANCELLED") {
                        Text("Remaining: ${formatInr(booking.remainingAmountInr)}", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                    }
                }
                StatusPill(booking.paymentStatus)
            }

            if (booking.status != "CANCELLED" && booking.status != "COMPLETED") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (booking.remainingAmountInr > 0L) {
                        GoldGradientButton(
                            text = "${strings.payRemaining} (${formatInr(booking.remainingAmountInr)})",
                            onClick = onPayRemaining,
                            modifier = Modifier.weight(1f),
                            testTag = "pay_remaining_${booking.id}"
                        )
                    }
                    OutlinedButton(
                        onClick = onCancel,
                        border = BorderStroke(1.dp, BookedRed.copy(alpha = 0.7f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(50.dp).testTag("cancel_booking_${booking.id}")
                    ) {
                        Text(strings.cancelBooking, color = BookedRed, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderCard(order: ProductOrder) {
    Card(
        colors = CardDefaults.cardColors(containerColor = OnyxCard),
        border = BorderStroke(1.dp, HairlineGoldBorder),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(order.vendorName, style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                StatusPill(order.orderStatus)
            }
            order.items.forEach { item ->
                Text(
                    "• ${item.productName} x${item.quantity} (${formatInr(item.unitPriceInr * item.quantity)})",
                    style = MaterialTheme.typography.bodyMedium,
                    color = IvoryText
                )
            }
            Text("Deliver to: ${order.deliveryAddress}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
            Spacer(Modifier.height(2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Paid via ${order.paymentMethod}", style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                Text(formatInr(order.totalAmountInr), style = MaterialTheme.typography.titleMedium, color = RoyalGold, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PaymentHistoryCard(pay: PaymentRecord) {
    Card(
        colors = CardDefaults.cardColors(containerColor = OnyxCard),
        border = BorderStroke(1.dp, HairlineGoldBorder),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("${pay.referenceType} • ${pay.paymentType}", style = MaterialTheme.typography.titleSmall, color = IvoryText)
                Text("${pay.upiApp} • Ref: ${pay.upiTransactionRef}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(formatInr(pay.amountInr), style = MaterialTheme.typography.titleMedium, color = RoyalGold, fontWeight = FontWeight.Bold)
                StatusPill(pay.status)
            }
        }
    }
}
