package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.MarketplaceConstants
import com.example.data.model.Product
import com.example.data.model.UiState
import com.example.i18n.AppStrings
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.OrnamentalDivider
import com.example.ui.components.ProductArtwork
import com.example.ui.components.StarRatingBadge
import com.example.ui.components.UpiPaymentDialog
import com.example.ui.components.formatInr
import com.example.ui.components.mangalamFieldColors
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.BookedRed
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ElevatedCharcoal
import com.example.ui.theme.HairlineGoldBorder
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalGold
import com.example.ui.viewmodel.MarketplaceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketplaceHomeScreen(
    viewModel: MarketplaceViewModel,
    strings: AppStrings,
    onOpenEventsForType: (String) -> Unit
) {
    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val addresses by viewModel.addresses.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val privateContact by viewModel.privateContact.collectAsStateWithLifecycle()
    val reviews by viewModel.activeTargetReviews.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }
    var sortLowToHigh by remember { mutableStateOf<Boolean?>(null) }
    var inspectingProduct by remember { mutableStateOf<Product?>(null) }
    var showCartSheet by remember { mutableStateOf(false) }
    var showUpiDialog by remember { mutableStateOf(false) }

    val defaultAddressText = remember(addresses) {
        val def = addresses.firstOrNull { it.defaultAddress } ?: addresses.firstOrNull()
        if (def != null) "${def.label}: ${def.addressLine}, ${def.city} - ${def.pincode}" else ""
    }
    var checkoutAddress by remember(defaultAddressText) { mutableStateOf(defaultAddressText) }

    val totalCartCount = cart.sumOf { it.quantity }
    val cartTotalInr = cart.sumOf { it.product.priceInr * it.quantity }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Luxury Hero Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, RoyalGold.copy(alpha = 0.6f))
                ) {
                    Box(modifier = Modifier.fillMaxWidth().height(190.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_celebration),
                            contentDescription = "M Mangalam Events Showcase",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            ObsidianBlack.copy(alpha = 0.92f),
                                            ObsidianBlack.copy(alpha = 0.45f)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = strings.appName.uppercase(),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = RoyalGold
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = strings.tagline,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ChampagneGold
                                )
                            }
                            Button(
                                onClick = { onOpenEventsForType("ALL") },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalGold),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("hero_book_event_btn")
                            ) {
                                Icon(Icons.Default.Celebration, contentDescription = null, tint = ObsidianBlack)
                                Spacer(Modifier.width(8.dp))
                                Text(strings.bookEventNow, color = ObsidianBlack, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 2. Plan a Celebration Quick Categories
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = strings.celebrationsTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = ChampagneGold,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(MarketplaceConstants.EVENT_TYPES) { eventType ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { onOpenEventsForType(eventType) }
                                    .testTag("quick_event_$eventType"),
                                color = OnyxCard,
                                border = BorderStroke(1.dp, HairlineGoldBorder),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Celebration,
                                        contentDescription = null,
                                        tint = RoyalGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = strings.eventTypeLabel(eventType),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = IvoryText
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Search & Product Category Filter
            item {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.featuredProductsTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = ChampagneGold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = sortLowToHigh == true,
                                onClick = { sortLowToHigh = if (sortLowToHigh == true) null else true },
                                label = { Text("₹ Low", style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = RoyalGold,
                                    selectedLabelColor = ObsidianBlack
                                )
                            )
                            FilterChip(
                                selected = sortLowToHigh == false,
                                onClick = { sortLowToHigh = if (sortLowToHigh == false) null else false },
                                label = { Text("₹ High", style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = RoyalGold,
                                    selectedLabelColor = ObsidianBlack
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(strings.searchProducts) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RoyalGold) },
                        singleLine = true,
                        colors = mangalamFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("product_search_input")
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = selectedCategory == "ALL",
                                onClick = { selectedCategory = "ALL" },
                                label = { Text(strings.allLabel) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = RoyalGold,
                                    selectedLabelColor = ObsidianBlack
                                )
                            )
                        }
                        items(MarketplaceConstants.PRODUCT_CATEGORIES) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(strings.productCategoryLabel(cat)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = RoyalGold,
                                    selectedLabelColor = ObsidianBlack
                                )
                            )
                        }
                    }
                }
            }

            // 4. Product Feed
            when (val state = productsState) {
                is UiState.Loading -> {
                    item {
                        Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = RoyalGold)
                        }
                    }
                }
                is UiState.Error -> {
                    item {
                        Text(
                            text = state.message,
                            color = BookedRed,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                is UiState.Success -> {
                    val filtered = state.data
                        .filter { prod ->
                            (selectedCategory == "ALL" || prod.category == selectedCategory) &&
                                (searchQuery.isBlank() ||
                                    prod.name.contains(searchQuery, ignoreCase = true) ||
                                    prod.description.contains(searchQuery, ignoreCase = true) ||
                                    prod.vendorName.contains(searchQuery, ignoreCase = true))
                        }
                        .let { list ->
                            when (sortLowToHigh) {
                                true -> list.sortedBy { it.priceInr }
                                false -> list.sortedByDescending { it.priceInr }
                                null -> list
                            }
                        }

                    if (filtered.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                colors = CardDefaults.cardColors(containerColor = OnyxCard),
                                border = BorderStroke(1.dp, HairlineGoldBorder)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.Storefront, contentDescription = null, tint = RoyalGold, modifier = Modifier.size(36.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("No matching celebration products yet.", color = ChampagneGold)
                                }
                            }
                        }
                    } else {
                        items(filtered, key = { it.id }) { product ->
                            ProductListingCard(
                                product = product,
                                strings = strings,
                                onInspect = {
                                    viewModel.watchProductReviews(product.id)
                                    inspectingProduct = product
                                },
                                onAddToCart = { viewModel.addToCart(product) },
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Floating Cart FAB
        if (totalCartCount > 0) {
            FloatingActionButton(
                onClick = { showCartSheet = true },
                containerColor = RoyalGold,
                contentColor = ObsidianBlack,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("open_cart_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BadgedBox(
                        badge = {
                            Badge(containerColor = ObsidianBlack, contentColor = ChampagneGold) {
                                Text(totalCartCount.toString())
                            }
                        }
                    ) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = strings.cartTitle)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(formatInr(cartTotalInr), fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Product Detail + Reviews Sheet
    inspectingProduct?.let { prod ->
        var reviewRating by remember { mutableIntStateOf(5) }
        var reviewText by remember { mutableStateOf("") }

        ModalBottomSheet(
            onDismissRequest = { inspectingProduct = null },
            containerColor = OnyxCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ProductArtwork(
                    base64Image = prod.imageBase64,
                    drawableKey = prod.drawableKey,
                    contentDescription = prod.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(prod.name, style = MaterialTheme.typography.titleLarge, color = RoyalGold, modifier = Modifier.weight(1f))
                    Text(formatInr(prod.priceInr), style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                }
                Text("${prod.vendorName} • ${strings.productCategoryLabel(prod.category)}", style = MaterialTheme.typography.labelLarge, color = MutedChampagne)
                Text(prod.description, style = MaterialTheme.typography.bodyMedium, color = IvoryText)
                GoldGradientButton(
                    text = if (prod.stock > 0) "${strings.addToCart} (${prod.stock} ${strings.inStock})" else strings.outOfStock,
                    enabled = prod.stock > 0,
                    onClick = {
                        viewModel.addToCart(prod)
                        inspectingProduct = null
                    }
                )
                OrnamentalDivider()
                Text(strings.reviewsTitle, style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                reviews.take(3).forEach { rev ->
                    Surface(color = ObsidianBlack, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(rev.userName, style = MaterialTheme.typography.labelLarge, color = ChampagneGold)
                                Text("★ ${rev.rating}/5", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                            }
                            Text(rev.comment, style = MaterialTheme.typography.bodyMedium, color = IvoryText)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    (1..5).forEach { star ->
                        IconButton(onClick = { reviewRating = star }, modifier = Modifier.size(34.dp)) {
                            Icon(
                                Icons.Default.Star,
                                contentDescription = "$star stars",
                                tint = if (star <= reviewRating) RoyalGold else MutedChampagne.copy(alpha = 0.3f)
                            )
                        }
                    }
                    OutlinedTextField(
                        value = reviewText,
                        onValueChange = { reviewText = it },
                        placeholder = { Text(strings.writeReview) },
                        colors = mangalamFieldColors(),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = {
                            if (reviewText.isNotBlank()) {
                                viewModel.submitReview("PRODUCT", prod.id, reviewRating, reviewText)
                                reviewText = ""
                            }
                        }
                    ) {
                        Text("Post", color = RoyalGold)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // Cart Bottom Sheet
    if (showCartSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCartSheet = false },
            containerColor = OnyxCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.cartTitle, style = MaterialTheme.typography.headlineMedium, color = RoyalGold)
                    IconButton(onClick = { showCartSheet = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MutedChampagne)
                    }
                }

                cart.forEach { entry ->
                    Surface(
                        color = ObsidianBlack,
                        border = BorderStroke(1.dp, HairlineGoldBorder),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(entry.product.name, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                Text(
                                    "${formatInr(entry.product.priceInr)} x ${entry.quantity}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = RoyalGold
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { viewModel.updateCartQuantity(entry.product.id, -1) }) {
                                    Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = ChampagneGold)
                                }
                                Text(entry.quantity.toString(), color = IvoryText, fontWeight = FontWeight.Bold)
                                IconButton(onClick = { viewModel.updateCartQuantity(entry.product.id, 1) }) {
                                    Icon(Icons.Default.Add, contentDescription = "Increase", tint = ChampagneGold)
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = checkoutAddress,
                    onValueChange = { checkoutAddress = it },
                    label = { Text("Delivery Address") },
                    colors = mangalamFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Payable", style = MaterialTheme.typography.titleMedium, color = MutedChampagne)
                    Text(formatInr(cartTotalInr), style = MaterialTheme.typography.titleLarge, color = RoyalGold)
                }

                GoldGradientButton(
                    text = "${strings.checkoutTitle} (${formatInr(cartTotalInr)})",
                    enabled = cart.isNotEmpty() && checkoutAddress.trim().length >= 3,
                    onClick = { showUpiDialog = true },
                    testTag = "proceed_cart_checkout_btn"
                )
                Spacer(Modifier.height(18.dp))
            }
        }
    }

    if (showUpiDialog) {
        UpiPaymentDialog(
            title = strings.upiPaymentTitle,
            amountInr = cartTotalInr,
            totalInr = cartTotalInr,
            allowAdvanceToggle = false,
            advanceAmountInr = cartTotalInr,
            strings = strings,
            isBusy = isBusy,
            onDismiss = { showUpiDialog = false },
            onConfirmPayment = { _, upiApp, upiId ->
                viewModel.checkoutCart(
                    customerName = userProfile?.displayName ?: viewModel.currentUserName,
                    customerPhone = privateContact?.mobileNumber ?: "9999999999",
                    deliveryAddress = checkoutAddress,
                    upiApp = upiApp,
                    upiId = upiId,
                    onSuccess = {
                        showUpiDialog = false
                        showCartSheet = false
                    }
                )
            }
        )
    }
}

@Composable
private fun ProductListingCard(
    product: Product,
    strings: AppStrings,
    onInspect: () -> Unit,
    onAddToCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onInspect)
            .testTag("product_card_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = OnyxCard),
        border = BorderStroke(1.dp, HairlineGoldBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProductArtwork(
                base64Image = product.imageBase64,
                drawableKey = product.drawableKey,
                contentDescription = product.name,
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(14.dp))
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = ElevatedCharcoal,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = strings.productCategoryLabel(product.category),
                            style = MaterialTheme.typography.labelSmall,
                            color = ChampagneGold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    StarRatingBadge(product.ratingAvg, product.reviewCount)
                }
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = IvoryText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = product.vendorName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MutedChampagne
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = formatInr(product.priceInr),
                            style = MaterialTheme.typography.titleMedium,
                            color = RoyalGold,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (product.stock > 0) "${product.stock} ${strings.inStock}" else strings.outOfStock,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (product.stock > 0) AvailableGreen else BookedRed
                        )
                    }
                    OutlinedButton(
                        onClick = onAddToCart,
                        enabled = product.stock > 0,
                        border = BorderStroke(1.dp, if (product.stock > 0) RoyalGold else HairlineGoldBorder),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("add_to_cart_${product.id}")
                    ) {
                        Text(
                            text = if (product.stock > 0) strings.addToCart else strings.outOfStock,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (product.stock > 0) RoyalGold else MutedChampagne
                        )
                    }
                }
            }
        }
    }
}
