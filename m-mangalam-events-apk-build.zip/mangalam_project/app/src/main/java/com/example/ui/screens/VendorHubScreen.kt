package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.firebase.ImageEncodingHelper
import com.example.data.model.EventService
import com.example.data.model.MarketplaceConstants
import com.example.data.model.SlotKey
import com.example.data.model.SlotStatus
import com.example.data.model.Vendor
import com.example.i18n.AppStrings
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.ProductArtwork
import com.example.ui.components.SmartCalendarWidget
import com.example.ui.components.StatusPill
import com.example.ui.components.formatInr
import com.example.ui.components.mangalamFieldColors
import com.example.ui.theme.BookedRed
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.HairlineGoldBorder
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalGold
import com.example.ui.viewmodel.MarketplaceViewModel

@Composable
fun VendorHubScreen(
    viewModel: MarketplaceViewModel,
    strings: AppStrings
) {
    val myVendor by viewModel.myVendor.collectAsStateWithLifecycle()
    val vendorProducts by viewModel.vendorProducts.collectAsStateWithLifecycle()
    val vendorServices by viewModel.vendorServices.collectAsStateWithLifecycle()
    val vendorBookings by viewModel.vendorBookings.collectAsStateWithLifecycle()
    val vendorOrders by viewModel.vendorOrders.collectAsStateWithLifecycle()
    val vendorAvailability by viewModel.vendorAvailability.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    val vendor = myVendor
    if (vendor == null || vendor.approvalStatus != "APPROVED") {
        VendorRegistrationSection(
            existingVendor = vendor,
            strings = strings,
            isBusy = isBusy,
            onSubmit = { vName, mobile, biz, city, loc, cat, docType, docImg ->
                viewModel.registerVendor(vName, mobile, biz, city, loc, cat, docType, docImg)
            }
        )
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddProductDialog by remember { mutableStateOf(false) }
    var showAddServiceDialog by remember { mutableStateOf(false) }

    val netBookingEarnings = vendorBookings.filter { it.status != "CANCELLED" }.sumOf { it.vendorPayoutInr }
    val netOrderEarnings = vendorOrders.filter { it.orderStatus != "CANCELLED" }.sumOf { it.vendorPayoutInr }

    Column(modifier = Modifier.fillMaxSize()) {
        // KPI Dashboard Strip
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(vendor.businessName, style = MaterialTheme.typography.titleLarge, color = RoyalGold)
                    Text("${vendor.city} • Fee ${vendor.commissionPercent}%", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                }
                StatusPill(vendor.approvalStatus)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VendorKpiCard(strings.totalOrders, vendorOrders.size.toString(), Modifier.weight(1f))
                VendorKpiCard(strings.totalBookings, vendorBookings.size.toString(), Modifier.weight(1f))
                VendorKpiCard(strings.netEarnings, formatInr(netBookingEarnings + netOrderEarnings), Modifier.weight(1.3f))
            }
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = ObsidianBlack,
            contentColor = RoyalGold,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = RoyalGold
                )
            }
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Products") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Services") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Calendar") })
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Orders") })
        }

        when (selectedTab) {
            0 -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        GoldGradientButton(
                            text = "+ Add New Product (with Photo Picker)",
                            onClick = { showAddProductDialog = true },
                            testTag = "vendor_add_product_btn"
                        )
                    }
                    items(vendorProducts, key = { it.id }) { prod ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ProductArtwork(
                                    base64Image = prod.imageBase64,
                                    drawableKey = prod.drawableKey,
                                    contentDescription = prod.name,
                                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(10.dp))
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.name, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                    Text("${prod.category} • Stock: ${prod.stock}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                    Text(formatInr(prod.priceInr), style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        GoldGradientButton(
                            text = "+ Add Event Service Package",
                            onClick = { showAddServiceDialog = true },
                            testTag = "vendor_add_service_btn"
                        )
                    }
                    items(vendorServices, key = { it.id }) { svc ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(svc.title, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                Text("${svc.eventType} • ${svc.city} • Advance ${svc.advancePercent}%", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                Text(formatInr(svc.basePriceInr), style = MaterialTheme.typography.titleMedium, color = RoyalGold)
                            }
                        }
                    }
                }
            }
            2 -> {
                var selectedService by remember(vendorServices) { mutableStateOf(vendorServices.firstOrNull()) }
                var selectedDate by remember { mutableStateOf("") }
                var selectedSlot by remember { mutableStateOf<SlotKey?>(null) }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (vendorServices.isEmpty()) {
                        item { Text("Add an Event Service first to manage its Smart Calendar.", color = MutedChampagne) }
                    } else {
                        item {
                            Text("Tap a date & slot to Block or Unblock availability:", style = MaterialTheme.typography.labelLarge, color = ChampagneGold)
                            Spacer(Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(vendorServices, key = { it.id }) { svc ->
                                    FilterChip(
                                        selected = selectedService?.id == svc.id,
                                        onClick = { selectedService = svc },
                                        label = { Text(svc.title) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = RoyalGold,
                                            selectedLabelColor = ObsidianBlack
                                        )
                                    )
                                }
                            }
                        }
                        selectedService?.let { svc ->
                            item {
                                val filteredAvail = vendorAvailability.filter { it.serviceId == svc.id }
                                SmartCalendarWidget(
                                    availabilitySlots = filteredAvail,
                                    currentUserId = viewModel.currentUserId,
                                    selectedDateIso = selectedDate,
                                    selectedSlotKey = selectedSlot,
                                    strings = strings,
                                    vendorManageMode = true,
                                    onDateSelected = { selectedDate = it; selectedSlot = null },
                                    onSlotSelected = { slotKey, status ->
                                        selectedSlot = slotKey
                                        if (status != SlotStatus.BOOKED) {
                                            viewModel.toggleVendorSlotBlock(
                                                service = svc,
                                                dateIso = selectedDate,
                                                slotKey = slotKey,
                                                block = status != SlotStatus.BLOCKED
                                            )
                                        } else {
                                            viewModel.showMessage("Confirmed bookings cannot be overwritten here.")
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
            else -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Text("Customer Event Bookings (${vendorBookings.size})", style = MaterialTheme.typography.titleSmall, color = RoyalGold) }
                    items(vendorBookings, key = { it.id }) { bkg ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(bkg.serviceTitle, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                    StatusPill(bkg.status)
                                }
                                Text("Customer: ${bkg.customerName} (${bkg.customerPhone})", style = MaterialTheme.typography.bodyMedium, color = ChampagneGold)
                                Text("Date: ${bkg.eventDateIso} • ${bkg.slotKey} • Guests: ${bkg.guestCount}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                Text("Venue: ${bkg.venueAddress}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                Text("Your Net Payout: ${formatInr(bkg.vendorPayoutInr)} (Fee: ${formatInr(bkg.commissionAmountInr)})", style = MaterialTheme.typography.labelLarge, color = RoyalGold)
                                if (bkg.status == "CONFIRMED") {
                                    OutlinedButton(
                                        onClick = { viewModel.cancelBooking(bkg, "Vendor unable to fulfill slot") },
                                        border = BorderStroke(1.dp, BookedRed.copy(alpha = 0.6f))
                                    ) {
                                        Text(strings.cancelBooking, color = BookedRed)
                                    }
                                }
                            }
                        }
                    }

                    item { Text("Customer Product Orders (${vendorOrders.size})", style = MaterialTheme.typography.titleSmall, color = RoyalGold) }
                    items(vendorOrders, key = { it.id }) { ord ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(ord.customerName, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                    StatusPill(ord.orderStatus)
                                }
                                Text("Phone: ${ord.customerPhone} • ${ord.deliveryAddress}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                Text("Your Net Payout: ${formatInr(ord.vendorPayoutInr)}", style = MaterialTheme.typography.labelLarge, color = RoyalGold)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("PACKED", "SHIPPED", "DELIVERED").forEach { next ->
                                        if (ord.orderStatus != next && ord.orderStatus != "DELIVERED") {
                                            OutlinedButton(
                                                onClick = { viewModel.updateOrderStatus(ord, next) },
                                                border = BorderStroke(1.dp, HairlineGoldBorder),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Text(next, style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddProductDialog) {
        AddProductDialog(
            vendor = vendor,
            isBusy = isBusy,
            onDismiss = { showAddProductDialog = false },
            onSave = { name, desc, cat, price, stock, imgBase64 ->
                val drawKey = when (cat) {
                    "Clothes", "Jewellery" -> "jewellery"
                    else -> "decor"
                }
                viewModel.saveProduct(vendor, null, name, desc, cat, price, stock, imgBase64, drawKey)
                showAddProductDialog = false
            }
        )
    }

    if (showAddServiceDialog) {
        AddServiceDialog(
            vendor = vendor,
            isBusy = isBusy,
            onDismiss = { showAddServiceDialog = false },
            onSave = { title, evt, city, desc, price, adv ->
                val drawKey = if (evt == "Wedding" || evt == "Engagement") "wedding" else "decor"
                viewModel.saveService(vendor, null, title, evt, city, desc, price, adv, drawKey)
                showAddServiceDialog = false
            }
        )
    }
}

@Composable
private fun VendorKpiCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = OnyxCard),
        border = BorderStroke(1.dp, HairlineGoldBorder),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
            Spacer(Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, color = RoyalGold, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun VendorRegistrationSection(
    existingVendor: Vendor?,
    strings: AppStrings,
    isBusy: Boolean,
    onSubmit: (String, String, String, String, String, String, String, String?) -> Unit
) {
    val context = LocalContext.current
    var vendorName by remember(existingVendor) { mutableStateOf(existingVendor?.vendorName ?: "") }
    var mobile by remember(existingVendor) { mutableStateOf(existingVendor?.mobileNumber ?: "") }
    var businessName by remember(existingVendor) { mutableStateOf(existingVendor?.businessName ?: "") }
    var city by remember(existingVendor) { mutableStateOf(existingVendor?.city ?: "") }
    var location by remember(existingVendor) { mutableStateOf(existingVendor?.location ?: "") }
    var serviceCat by remember(existingVendor) { mutableStateOf(existingVendor?.serviceCategory?.ifBlank { "Wedding" } ?: "Wedding") }
    var docType by remember(existingVendor) { mutableStateOf(existingVendor?.documentType?.ifBlank { "GST Certificate" } ?: "GST Certificate") }
    var docBase64 by remember(existingVendor) { mutableStateOf(existingVendor?.documentImageBase64) }

    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            docBase64 = ImageEncodingHelper.encodePickerUriToBase64(context, uri)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (existingVendor != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = OnyxCard),
                    border = BorderStroke(1.dp, RoyalGold),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Vendor Verification Status", style = MaterialTheme.typography.titleMedium, color = RoyalGold)
                            StatusPill(existingVendor.approvalStatus)
                        }
                        Text(
                            text = if (existingVendor.approvalStatus == "PENDING") {
                                "Your application for ${existingVendor.businessName} is under Admin review."
                            } else {
                                "Rejected: ${existingVendor.rejectionReason ?: "Please re-submit valid documents."}"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = IvoryText
                        )
                    }
                }
            }
        }

        if (existingVendor == null || existingVendor.approvalStatus == "REJECTED") {
            item {
                Text(strings.becomeVendorTitle, style = MaterialTheme.typography.headlineMedium, color = RoyalGold)
                Text("Register your celebration business, verify KYC documents, and start selling or accepting bookings.", style = MaterialTheme.typography.bodyMedium, color = MutedChampagne)
            }
            item {
                OutlinedTextField(value = vendorName, onValueChange = { vendorName = it }, label = { Text("Vendor Full Name") }, colors = mangalamFieldColors(), modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(value = mobile, onValueChange = { mobile = it.filter { c -> c.isDigit() }.take(12) }, label = { Text("Mobile Number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), colors = mangalamFieldColors(), modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(value = businessName, onValueChange = { businessName = it }, label = { Text("Business Name") }, colors = mangalamFieldColors(), modifier = Modifier.fillMaxWidth())
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") }, colors = mangalamFieldColors(), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Area / Location") }, colors = mangalamFieldColors(), modifier = Modifier.weight(1f))
                }
            }
            item {
                Text("Service Category", style = MaterialTheme.typography.labelLarge, color = ChampagneGold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(MarketplaceConstants.VENDOR_CATEGORIES) { cat ->
                        FilterChip(
                            selected = serviceCat == cat,
                            onClick = { serviceCat = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalGold, selectedLabelColor = ObsidianBlack)
                        )
                    }
                }
            }
            item {
                Text("Document Verification Type", style = MaterialTheme.typography.labelLarge, color = ChampagneGold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(MarketplaceConstants.DOCUMENT_TYPES) { doc ->
                        FilterChip(
                            selected = docType == doc,
                            onClick = { docType = doc },
                            label = { Text(doc) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalGold, selectedLabelColor = ObsidianBlack)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { docPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    border = BorderStroke(1.dp, RoyalGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, tint = RoyalGold)
                    Spacer(Modifier.width(8.dp))
                    Text(if (docBase64 != null) "Document Photo Attached ✓ (Tap to Change)" else "Upload Verification Document Photo", color = ChampagneGold)
                }
            }
            item {
                val formValid = vendorName.trim().length >= 2 && mobile.length >= 10 && businessName.trim().length >= 2 && city.trim().length >= 2 && location.trim().length >= 2
                GoldGradientButton(
                    text = "Submit for Admin Approval",
                    enabled = formValid,
                    isLoading = isBusy,
                    onClick = { onSubmit(vendorName, mobile, businessName, city, location, serviceCat, docType, docBase64) },
                    testTag = "submit_vendor_reg_btn"
                )
            }
        }
    }
}

@Composable
private fun AddProductDialog(
    vendor: Vendor,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Long, Long, String?) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(MarketplaceConstants.PRODUCT_CATEGORIES.first()) }
    var price by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("10") }
    var imgBase64 by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            imgBase64 = ImageEncodingHelper.encodePickerUriToBase64(context, uri)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxCard,
        title = { Text("Publish Celebration Product", color = RoyalGold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    border = BorderStroke(1.dp, RoyalGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, tint = RoyalGold)
                    Spacer(Modifier.width(8.dp))
                    Text(if (imgBase64 != null) "Product Image Ready ✓" else "Pick Product Image", color = ChampagneGold)
                }
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name") }, colors = mangalamFieldColors(), singleLine = true)
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") }, colors = mangalamFieldColors())
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(MarketplaceConstants.PRODUCT_CATEGORIES) { c ->
                        FilterChip(
                            selected = cat == c,
                            onClick = { cat = c },
                            label = { Text(c) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalGold, selectedLabelColor = ObsidianBlack)
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = price, onValueChange = { price = it.filter { ch -> ch.isDigit() } }, label = { Text("Price ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = mangalamFieldColors(), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = stock, onValueChange = { stock = it.filter { ch -> ch.isDigit() } }, label = { Text("Stock") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = mangalamFieldColors(), modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            val pVal = price.toLongOrNull() ?: 0L
            val sVal = stock.toLongOrNull() ?: 0L
            GoldGradientButton(
                text = "Publish Product",
                enabled = name.trim().length >= 2 && desc.trim().length >= 2 && pVal > 0L,
                isLoading = isBusy,
                onClick = { onSave(name, desc, cat, pVal, sVal, imgBase64) }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = MutedChampagne) }
        }
    )
}

@Composable
private fun AddServiceDialog(
    vendor: Vendor,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, Long, Long) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var eventType by remember { mutableStateOf(MarketplaceConstants.EVENT_TYPES.first()) }
    var city by remember { mutableStateOf(vendor.city) }
    var desc by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var advancePct by remember { mutableStateOf("30") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxCard,
        title = { Text("Add Event Booking Package", color = RoyalGold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Package Title") }, colors = mangalamFieldColors(), singleLine = true)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(MarketplaceConstants.EVENT_TYPES) { evt ->
                        FilterChip(
                            selected = eventType == evt,
                            onClick = { eventType = evt },
                            label = { Text(evt) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalGold, selectedLabelColor = ObsidianBlack)
                        )
                    }
                }
                OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") }, colors = mangalamFieldColors(), singleLine = true)
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Package Details") }, colors = mangalamFieldColors())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = price, onValueChange = { price = it.filter { ch -> ch.isDigit() } }, label = { Text("Base Price ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = mangalamFieldColors(), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = advancePct, onValueChange = { advancePct = it.filter { ch -> ch.isDigit() } }, label = { Text("Advance %") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = mangalamFieldColors(), modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            val pVal = price.toLongOrNull() ?: 0L
            val aVal = (advancePct.toLongOrNull() ?: 30L).coerceIn(10L, 100L)
            GoldGradientButton(
                text = "Save Event Package",
                enabled = title.trim().length >= 2 && desc.trim().length >= 2 && pVal > 0L,
                isLoading = isBusy,
                onClick = { onSave(title, eventType, city, desc, pVal, aVal) }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = MutedChampagne) }
        }
    )
}
