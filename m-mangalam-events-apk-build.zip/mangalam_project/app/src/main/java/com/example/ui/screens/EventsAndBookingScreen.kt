package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.EventService
import com.example.data.model.MarketplaceConstants
import com.example.data.model.SlotKey
import com.example.data.model.SlotStatus
import com.example.data.model.UiState
import com.example.i18n.AppStrings
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.OrnamentalDivider
import com.example.ui.components.ProductArtwork
import com.example.ui.components.SmartCalendarWidget
import com.example.ui.components.StarRatingBadge
import com.example.ui.components.UpiPaymentDialog
import com.example.ui.components.formatInr
import com.example.ui.components.mangalamFieldColors
import com.example.ui.theme.BookedRed
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ElevatedCharcoal
import com.example.ui.theme.HairlineGoldBorder
import com.example.ui.theme.InfoIndigoBg
import com.example.ui.theme.IvoryText
import com.example.ui.theme.LockedBlue
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalGold
import com.example.ui.viewmodel.MarketplaceViewModel
import kotlin.math.roundToLong

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventsAndBookingScreen(
    viewModel: MarketplaceViewModel,
    strings: AppStrings,
    initialEventTypeFilter: String
) {
    val servicesState by viewModel.servicesState.collectAsStateWithLifecycle()
    val availability by viewModel.selectedServiceAvailability.collectAsStateWithLifecycle()
    val lockedSlot by viewModel.lockedSlot.collectAsStateWithLifecycle()
    val addresses by viewModel.addresses.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val privateContact by viewModel.privateContact.collectAsStateWithLifecycle()
    val reviews by viewModel.activeTargetReviews.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    var selectedEventType by remember { mutableStateOf(initialEventTypeFilter) }
    var searchQuery by remember { mutableStateOf("") }
    var activeService by remember { mutableStateOf<EventService?>(null) }

    LaunchedEffect(initialEventTypeFilter) {
        selectedEventType = initialEventTypeFilter
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(strings.searchEvents) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RoyalGold) },
                colors = mangalamFieldColors(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().testTag("event_search_input")
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedEventType == "ALL",
                        onClick = { selectedEventType = "ALL" },
                        label = { Text(strings.allLabel) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalGold,
                            selectedLabelColor = ObsidianBlack
                        )
                    )
                }
                items(MarketplaceConstants.EVENT_TYPES) { evt ->
                    FilterChip(
                        selected = selectedEventType == evt,
                        onClick = { selectedEventType = evt },
                        label = { Text(strings.eventTypeLabel(evt)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalGold,
                            selectedLabelColor = ObsidianBlack
                        )
                    )
                }
            }
        }

        when (val state = servicesState) {
            is UiState.Loading -> {
                item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = RoyalGold)
                    }
                }
            }
            is UiState.Error -> {
                item { Text(state.message, color = BookedRed) }
            }
            is UiState.Success -> {
                val filtered = state.data.filter { svc ->
                    (selectedEventType == "ALL" || svc.eventType == selectedEventType) &&
                        (searchQuery.isBlank() ||
                            svc.title.contains(searchQuery, ignoreCase = true) ||
                            svc.city.contains(searchQuery, ignoreCase = true) ||
                            svc.vendorName.contains(searchQuery, ignoreCase = true))
                }
                items(filtered, key = { it.id }) { service ->
                    EventServiceCard(
                        service = service,
                        strings = strings,
                        onBookClick = {
                            viewModel.watchServiceCalendar(service.id)
                            activeService = service
                        }
                    )
                }
            }
        }
    }

    // Smart Booking Calendar & Checkout Sheet
    activeService?.let { svc ->
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        var selectedDateIso by remember { mutableStateOf("") }
        var selectedSlotKey by remember { mutableStateOf<SlotKey?>(null) }
        val defaultVenue = remember(addresses) {
            val def = addresses.firstOrNull { it.defaultAddress } ?: addresses.firstOrNull()
            if (def != null) "${def.addressLine}, ${def.city} - ${def.pincode}" else "${svc.city} Celebration Lawns"
        }
        var venueAddress by remember(defaultVenue) { mutableStateOf(defaultVenue) }
        var guestCountStr by remember { mutableStateOf("250") }
        var showUpiCheckout by remember { mutableStateOf(false) }
        var reviewRating by remember { mutableIntStateOf(5) }
        var reviewText by remember { mutableStateOf("") }

        val advanceAmt = remember(svc) {
            ((svc.basePriceInr * svc.advancePercent) / 100.0).roundToLong().coerceAtLeast(1L)
        }

        ModalBottomSheet(
            onDismissRequest = {
                viewModel.releaseCurrentSlotLock()
                activeService = null
            },
            sheetState = sheetState,
            containerColor = OnyxCard
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                contentPadding = PaddingValues(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(svc.title, style = MaterialTheme.typography.titleLarge, color = RoyalGold)
                            Text("${svc.vendorName} • ${svc.city}", style = MaterialTheme.typography.bodyMedium, color = MutedChampagne)
                        }
                        IconButton(onClick = {
                            viewModel.releaseCurrentSlotLock()
                            activeService = null
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = MutedChampagne)
                        }
                    }
                }

                item {
                    Text(svc.description, style = MaterialTheme.typography.bodyMedium, color = IvoryText)
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Package: ${formatInr(svc.basePriceInr)}", style = MaterialTheme.typography.titleSmall, color = ChampagneGold)
                        Text("Advance (${svc.advancePercent}%): ${formatInr(advanceAmt)}", style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                    }
                }

                item {
                    Text(strings.smartCalendarTitle, style = MaterialTheme.typography.titleMedium, color = RoyalGold)
                    Text(strings.selectDatePrompt, style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                    Spacer(Modifier.height(8.dp))
                    SmartCalendarWidget(
                        availabilitySlots = availability,
                        currentUserId = viewModel.currentUserId,
                        selectedDateIso = selectedDateIso,
                        selectedSlotKey = selectedSlotKey,
                        strings = strings,
                        onDateSelected = { iso ->
                            selectedDateIso = iso
                            selectedSlotKey = null
                        },
                        onSlotSelected = { slotKey, status ->
                            if (status == SlotStatus.AVAILABLE || status == SlotStatus.LOCKED) {
                                selectedSlotKey = slotKey
                            }
                        }
                    )
                }

                if (lockedSlot != null && lockedSlot?.serviceId == svc.id) {
                    item {
                        Surface(
                            color = InfoIndigoBg,
                            border = BorderStroke(1.dp, LockedBlue),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = LockedBlue)
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = strings.slotLockBanner,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = IvoryText
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = venueAddress,
                        onValueChange = { venueAddress = it },
                        label = { Text("Event Venue Address") },
                        colors = mangalamFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = guestCountStr,
                        onValueChange = { guestCountStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Estimated Guest Count") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = mangalamFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    val slotReady = selectedDateIso.isNotBlank() && selectedSlotKey != null
                    GoldGradientButton(
                        text = if (slotReady) "Lock Slot & Proceed to UPI Checkout" else strings.selectSlotPrompt,
                        enabled = slotReady && venueAddress.trim().length >= 3,
                        isLoading = isBusy,
                        onClick = {
                            val slotKey = selectedSlotKey ?: return@GoldGradientButton
                            viewModel.lockSlot(svc, selectedDateIso, slotKey) {
                                showUpiCheckout = true
                            }
                        },
                        testTag = "lock_and_checkout_btn"
                    )
                }

                item {
                    OrnamentalDivider()
                    Text(strings.reviewsTitle, style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                }

                items(reviews.take(3)) { rev ->
                    Surface(color = ObsidianBlack, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(rev.userName, style = MaterialTheme.typography.labelLarge, color = ChampagneGold)
                                Text("★ ${rev.rating}/5", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                            }
                            Text(rev.comment, style = MaterialTheme.typography.bodyMedium, color = IvoryText)
                        }
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        (1..5).forEach { star ->
                            IconButton(onClick = { reviewRating = star }, modifier = Modifier.size(34.dp)) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "$star stars",
                                    tint = if (star <= reviewRating) RoyalGold else MutedChampagne.copy(alpha = 0.3f)
                                )
                            }
                        }
                        OutlinedTextField(
                            value = reviewText,
                            onValueChange = { reviewText = it },
                            placeholder = { Text(strings.writeReview) },
                            colors = mangalamFieldColors(),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = {
                                if (reviewText.isNotBlank()) {
                                    viewModel.submitReview("SERVICE", svc.id, reviewRating, reviewText)
                                    reviewText = ""
                                }
                            }
                        ) {
                            Text("Post", color = RoyalGold)
                        }
                    }
                }
            }
        }

        if (showUpiCheckout && selectedSlotKey != null && selectedDateIso.isNotBlank()) {
            UpiPaymentDialog(
                title = "${strings.upiPaymentTitle} • ${svc.eventType}",
                amountInr = advanceAmt,
                totalInr = svc.basePriceInr,
                allowAdvanceToggle = true,
                advanceAmountInr = advanceAmt,
                strings = strings,
                isBusy = isBusy,
                onDismiss = {
                    showUpiCheckout = false
                    viewModel.releaseCurrentSlotLock()
                },
                onConfirmPayment = { payFull, upiApp, upiId ->
                    viewModel.confirmEventBooking(
                        service = svc,
                        dateIso = selectedDateIso,
                        slotKey = selectedSlotKey!!,
                        customerName = userProfile?.displayName ?: viewModel.currentUserName,
                        customerPhone = privateContact?.mobileNumber ?: "9999999999",
                        venueAddress = venueAddress,
                        guestCount = guestCountStr.toLongOrNull()?.coerceAtLeast(1L) ?: 100L,
                        payFullAmount = payFull,
                        upiApp = upiApp,
                        upiId = upiId,
                        onBooked = {
                            showUpiCheckout = false
                            activeService = null
                        }
                    )
                }
            )
        }
    }
}

@Composable
private fun EventServiceCard(
    service: EventService,
    strings: AppStrings,
    onBookClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onBookClick)
            .testTag("service_card_${service.id}"),
        colors = CardDefaults.cardColors(containerColor = OnyxCard),
        border = BorderStroke(1.dp, HairlineGoldBorder),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column {
            ProductArtwork(
                base64Image = null,
                drawableKey = service.drawableKey,
                contentDescription = service.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(155.dp)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            )
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(color = ElevatedCharcoal, shape = RoundedCornerShape(8.dp)) {
                        Text(
                            text = strings.eventTypeLabel(service.eventType),
                            style = MaterialTheme.typography.labelSmall,
                            color = RoyalGold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    StarRatingBadge(service.ratingAvg, service.reviewCount)
                }

                Text(service.title, style = MaterialTheme.typography.titleMedium, color = IvoryText)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = RoyalGold, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("${service.vendorName} • ${service.city}", style = MaterialTheme.typography.bodyMedium, color = MutedChampagne)
                }
                Text(service.description, style = MaterialTheme.typography.bodyMedium, color = MutedChampagne, maxLines = 2)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(formatInr(service.basePriceInr), style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                        Text("Advance ${service.advancePercent}%", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                    }
                    Surface(
                        color = RoyalGold,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.clickable(onClick = onBookClick).testTag("book_service_${service.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = ObsidianBlack, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.bookEventNow, style = MaterialTheme.typography.labelLarge, color = ObsidianBlack, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
