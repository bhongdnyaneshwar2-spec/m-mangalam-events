package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.firebase.MarketplaceRepository
import com.example.data.firebase.signOutUser
import com.example.i18n.AppLanguage
import com.example.i18n.AppStrings
import com.example.i18n.LanguagePreferences
import com.example.ui.components.LanguageSelectorDialog
import com.example.ui.components.MangalamTopHeader
import com.example.ui.screens.AdminHubScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.EventsAndBookingScreen
import com.example.ui.screens.MarketplaceHomeScreen
import com.example.ui.screens.OrdersAndBookingsScreen
import com.example.ui.screens.ProfileAndNotificationsScreen
import com.example.ui.screens.VendorHubScreen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ElevatedCharcoal
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MangalamTheme
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.VelvetSurface
import com.example.ui.viewmodel.MarketplaceViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

private const val ROUTE_MARKET = "market"
private const val ROUTE_EVENTS = "events"
private const val ROUTE_ORDERS = "orders"
private const val ROUTE_VENDOR = "vendor"
private const val ROUTE_ADMIN = "admin"
private const val ROUTE_PROFILE = "profile"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MangalamTheme {
                MangalamAppRoot()
            }
        }
    }
}

@Composable
fun MangalamAppRoot() {
    val context = LocalContext.current
    val languagePrefs = remember(context) { LanguagePreferences(context.applicationContext) }
    val preAuthLang by languagePrefs.languageFlow.collectAsStateWithLifecycle(initialValue = AppLanguage.EN)
    val scope = rememberCoroutineScope()

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(
            selectedLanguage = preAuthLang,
            onLanguageSelected = { lang -> scope.launch { languagePrefs.setLanguage(lang) } },
            onAuthSuccess = { currentUser = Firebase.auth.currentUser }
        )
    } else {
        val uid = user.uid
        key(uid) {
            val viewModel: MarketplaceViewModel = viewModel(
                key = uid,
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY])
                        val dbId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(dbId)
                        MarketplaceViewModel(
                            repository = MarketplaceRepository(db),
                            languagePreferences = LanguagePreferences(app),
                            currentUserId = uid,
                            currentUserEmail = user.email,
                            currentUserName = user.displayName ?: "Celebration Guest",
                            currentPhotoUrl = user.photoUrl?.toString()
                        )
                    }
                }
            )
            AuthenticatedMarketplaceShell(viewModel = viewModel)
        }
    }
}

private data class NavTab(
    val route: String,
    val label: String,
    val icon: ImageVector
)

@Composable
private fun AuthenticatedMarketplaceShell(viewModel: MarketplaceViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: ROUTE_MARKET

    val language by viewModel.language.collectAsStateWithLifecycle()
    val strings = remember(language) { AppStrings.forLanguage(language) }
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val snackbarMsg by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val isAdmin = userProfile?.role == "ADMIN" || viewModel.isBootstrapAdmin
    val unreadCount = notifications.count { !it.readFlag }
    val snackbarHostState = remember { SnackbarHostState() }

    var showLanguageDialog by remember { mutableStateOf(false) }
    var eventFilterForNavigation by remember { mutableStateOf("ALL") }

    LaunchedEffect(snackbarMsg) {
        val msg = snackbarMsg
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val tabs = remember(strings, isAdmin) {
        buildList {
            add(NavTab(ROUTE_MARKET, strings.navShop, Icons.Default.Storefront))
            add(NavTab(ROUTE_EVENTS, strings.navEvents, Icons.Default.Celebration))
            add(NavTab(ROUTE_ORDERS, strings.navOrders, Icons.Default.EventNote))
            add(NavTab(ROUTE_VENDOR, strings.navVendor, Icons.Default.WorkspacePremium))
            if (isAdmin) {
                add(NavTab(ROUTE_ADMIN, strings.navAdmin, Icons.Default.AdminPanelSettings))
            }
            add(NavTab(ROUTE_PROFILE, strings.navProfile, Icons.Default.Person))
        }
    }

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(ROUTE_MARKET) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(ObsidianBlack)) {
        val useRail = maxWidth >= 720.dp

        Scaffold(
            containerColor = ObsidianBlack,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = {
                SnackbarHost(snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = ElevatedCharcoal,
                        contentColor = ChampagneGold
                    )
                }
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(containerColor = VelvetSurface) {
                        tabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = {
                                    Text(
                                        text = tab.label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = RoyalGold,
                                    indicatorColor = RoyalGold,
                                    unselectedIconColor = MutedChampagne,
                                    unselectedTextColor = MutedChampagne
                                ),
                                modifier = Modifier.testTag("nav_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                if (useRail) {
                    NavigationRail(
                        containerColor = VelvetSurface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        tabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label, maxLines = 1) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = RoyalGold,
                                    indicatorColor = RoyalGold,
                                    unselectedIconColor = MutedChampagne,
                                    unselectedTextColor = MutedChampagne
                                )
                            )
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    MangalamTopHeader(
                        title = strings.appName,
                        subtitle = strings.tagline,
                        unreadNotifications = unreadCount,
                        currentLanguage = language,
                        onLanguageClick = { showLanguageDialog = true },
                        onNotificationsClick = { navigateToTab(ROUTE_PROFILE) }
                    )

                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_MARKET,
                        modifier = Modifier.weight(1f)
                    ) {
                        composable(ROUTE_MARKET) {
                            MarketplaceHomeScreen(
                                viewModel = viewModel,
                                strings = strings,
                                onOpenEventsForType = { evtType ->
                                    eventFilterForNavigation = evtType
                                    navigateToTab(ROUTE_EVENTS)
                                }
                            )
                        }
                        composable(ROUTE_EVENTS) {
                            EventsAndBookingScreen(
                                viewModel = viewModel,
                                strings = strings,
                                initialEventTypeFilter = eventFilterForNavigation
                            )
                        }
                        composable(ROUTE_ORDERS) {
                            OrdersAndBookingsScreen(viewModel = viewModel, strings = strings)
                        }
                        composable(ROUTE_VENDOR) {
                            VendorHubScreen(viewModel = viewModel, strings = strings)
                        }
                        composable(ROUTE_ADMIN) {
                            if (isAdmin) {
                                AdminHubScreen(viewModel = viewModel, strings = strings)
                            } else {
                                Box(Modifier.fillMaxSize().padding(24.dp)) {
                                    Text("Admin access required.", color = IvoryText)
                                }
                            }
                        }
                        composable(ROUTE_PROFILE) {
                            ProfileAndNotificationsScreen(
                                viewModel = viewModel,
                                strings = strings,
                                currentLanguage = language,
                                onSignOutClick = {
                                    signOutUser(credentialManager, scope)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showLanguageDialog) {
        LanguageSelectorDialog(
            current = language,
            onSelect = { viewModel.setLanguage(it) },
            onDismiss = { showLanguageDialog = false }
        )
    }
}
