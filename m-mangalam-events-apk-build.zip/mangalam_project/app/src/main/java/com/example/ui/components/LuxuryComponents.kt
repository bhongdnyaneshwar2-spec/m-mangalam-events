package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.firebase.ImageEncodingHelper
import com.example.data.model.MarketplaceConstants
import com.example.i18n.AppLanguage
import com.example.i18n.AppStrings
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.AvailableGreenBg
import com.example.ui.theme.BookedRed
import com.example.ui.theme.BookedRedBg
import com.example.ui.theme.BurnishedGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ElevatedCharcoal
import com.example.ui.theme.HairlineGoldBorder
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.PendingOrange
import com.example.ui.theme.PendingOrangeBg
import com.example.ui.theme.RoyalGold
import java.text.NumberFormat
import java.util.Locale

fun formatInr(amount: Long): String {
    val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
    return "₹${nf.format(amount)}"
}

@Composable
fun GoldGradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    testTag: String = ""
) {
    Button(
        onClick = onClick,
        enabled = enabled && !isLoading,
        modifier = modifier
            .height(50.dp)
            .then(if (testTag.isNotBlank()) Modifier.testTag(testTag) else Modifier),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            disabledContainerColor = ElevatedCharcoal
        ),
        contentPadding = PaddingValues(0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .background(
                    brush = if (enabled) {
                        Brush.horizontalGradient(listOf(RoyalGold, ChampagneGold, BurnishedGold))
                    } else {
                        Brush.horizontalGradient(listOf(ElevatedCharcoal, ElevatedCharcoal))
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = ObsidianBlack,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (enabled) ObsidianBlack else MutedChampagne,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ProductArtwork(
    base64Image: String?,
    drawableKey: String,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    val bitmap = remember(base64Image) { ImageEncodingHelper.decodeBase64ToImageBitmap(base64Image) }
    if (bitmap != null) {
        Image(
            bitmap = bitmap,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = ContentScale.Crop
        )
    } else {
        Image(
            painter = painterResource(id = ImageEncodingHelper.drawableResForKey(drawableKey)),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
fun StatusPill(status: String) {
    val (bg, fg) = when (status.uppercase()) {
        "APPROVED", "CONFIRMED", "FULLY_PAID", "DELIVERED", "SUCCESS", "AVAILABLE", "RESOLVED" ->
            AvailableGreenBg to AvailableGreen
        "PENDING", "ADVANCE_PAID", "PLACED", "PACKED", "SHIPPED", "IN_REVIEW", "REFUND_REQUESTED", "REFUND_PENDING" ->
            PendingOrangeBg to PendingOrange
        "REJECTED", "CANCELLED", "BOOKED", "OPEN" ->
            BookedRedBg to BookedRed
        else -> ElevatedCharcoal to ChampagneGold
    }
    Surface(
        color = bg,
        border = BorderStroke(1.dp, fg.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(50)
    ) {
        Text(
            text = status.replace("_", " "),
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun StarRatingBadge(rating: Double, reviewCount: Long) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = Icons.Default.Star,
            contentDescription = "Rating",
            tint = RoyalGold,
            modifier = Modifier.size(15.dp)
        )
        Spacer(Modifier.width(4.dp))
        Text(
            text = String.format(Locale.US, "%.1f", rating) + if (reviewCount > 0) " ($reviewCount)" else "",
            style = MaterialTheme.typography.labelSmall,
            color = ChampagneGold
        )
    }
}

@Composable
fun MangalamTopHeader(
    title: String,
    subtitle: String? = null,
    unreadNotifications: Int,
    currentLanguage: AppLanguage,
    onLanguageClick: () -> Unit,
    onNotificationsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = RoyalGold
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedChampagne
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onLanguageClick)
                    .testTag("header_language_btn"),
                color = OnyxCard,
                border = BorderStroke(1.dp, HairlineGoldBorder),
                shape = RoundedCornerShape(50)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Change language",
                        tint = RoyalGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = currentLanguage.nativeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampagneGold
                    )
                }
            }
            Spacer(Modifier.width(6.dp))
            Box {
                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier.testTag("header_notifications_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = RoyalGold
                    )
                }
                if (unreadNotifications > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 6.dp, end = 6.dp)
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(BookedRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = unreadNotifications.coerceAtMost(9).toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = IvoryText
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LanguageSelectorDialog(
    current: AppLanguage,
    onSelect: (AppLanguage) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxCard,
        title = { Text("Select Language / भाषा निवडा", color = RoyalGold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AppLanguage.entries.forEach { lang ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelect(lang); onDismiss() },
                        color = if (lang == current) ElevatedCharcoal else ObsidianBlack,
                        border = BorderStroke(1.dp, if (lang == current) RoyalGold else HairlineGoldBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(lang.nativeLabel, color = IvoryText, style = MaterialTheme.typography.titleSmall)
                            if (lang == current) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RoyalGold)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = RoyalGold) }
        }
    )
}

@Composable
fun UpiPaymentDialog(
    title: String,
    amountInr: Long,
    totalInr: Long,
    allowAdvanceToggle: Boolean,
    advanceAmountInr: Long,
    strings: AppStrings,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onConfirmPayment: (payFull: Boolean, upiApp: String, upiId: String) -> Unit
) {
    var payFull by remember { mutableStateOf(!allowAdvanceToggle) }
    var selectedUpiApp by remember { mutableStateOf(MarketplaceConstants.UPI_APPS.first()) }
    var upiId by remember { mutableStateOf("celebration@okaxis") }
    val payable = if (allowAdvanceToggle && !payFull) advanceAmountInr else totalInr

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxCard,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = RoyalGold)
                Spacer(Modifier.width(8.dp))
                Text(title, color = RoyalGold, style = MaterialTheme.typography.titleMedium)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (allowAdvanceToggle) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { payFull = false },
                            color = if (!payFull) ElevatedCharcoal else ObsidianBlack,
                            border = BorderStroke(1.dp, if (!payFull) RoyalGold else HairlineGoldBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(strings.payAdvance, style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                Text(formatInr(advanceAmountInr), style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                            }
                        }
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { payFull = true },
                            color = if (payFull) ElevatedCharcoal else ObsidianBlack,
                            border = BorderStroke(1.dp, if (payFull) RoyalGold else HairlineGoldBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(strings.payFull, style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                Text(formatInr(totalInr), style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                            }
                        }
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianBlack),
                    border = BorderStroke(1.dp, HairlineGoldBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Payable Now via UPI", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                        Text(formatInr(payable), style = MaterialTheme.typography.headlineMedium, color = ChampagneGold)
                        if (allowAdvanceToggle && !payFull) {
                            Text(
                                "Remaining balance ${formatInr(totalInr - advanceAmountInr)} can be paid later from Bookings.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedChampagne
                            )
                        }
                    }
                }

                Text("Choose UPI App", style = MaterialTheme.typography.labelLarge, color = IvoryText)
                MarketplaceConstants.UPI_APPS.forEach { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedUpiApp = app }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedUpiApp == app,
                            onClick = { selectedUpiApp = app },
                            colors = RadioButtonDefaults.colors(selectedColor = RoyalGold)
                        )
                        Text(app, color = IvoryText, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                OutlinedTextField(
                    value = upiId,
                    onValueChange = { upiId = it },
                    label = { Text("Your UPI ID") },
                    singleLine = true,
                    colors = mangalamFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            GoldGradientButton(
                text = "${strings.confirmAndPay} (${formatInr(payable)})",
                isLoading = isBusy,
                enabled = upiId.contains("@") && upiId.length >= 5,
                onClick = { onConfirmPayment(payFull, selectedUpiApp, upiId.trim()) },
                testTag = "confirm_upi_payment_btn"
            )
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, border = BorderStroke(1.dp, HairlineGoldBorder)) {
                Text("Cancel", color = MutedChampagne)
            }
        }
    )
}

@Composable
fun mangalamFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = RoyalGold,
    unfocusedBorderColor = HairlineGoldBorder,
    focusedLabelColor = RoyalGold,
    unfocusedLabelColor = MutedChampagne,
    focusedTextColor = IvoryText,
    unfocusedTextColor = IvoryText,
    cursorColor = RoyalGold
)

@Composable
fun OrnamentalDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(vertical = 8.dp),
        thickness = 1.dp,
        color = HairlineGoldBorder
    )
}
