package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.data.model.AppNotification
import com.example.data.model.AvailabilitySlot
import com.example.data.model.CartEntry
import com.example.data.model.CategoryItem
import com.example.data.model.ComplaintItem
import com.example.data.model.EventBooking
import com.example.data.model.EventService
import com.example.data.model.MarketplaceConstants
import com.example.data.model.PaymentRecord
import com.example.data.model.PlatformConfig
import com.example.data.model.PrivateContact
import com.example.data.model.Product
import com.example.data.model.ProductOrder
import com.example.data.model.ReviewItem
import com.example.data.model.SlotKey
import com.example.data.model.UserAddress
import com.example.data.model.UserProfile
import com.example.data.model.Vendor
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID
import kotlin.math.roundToLong

class MarketplaceRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    private fun sanitizeId(raw: String): String =
        raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")

    private val estimate = DocumentSnapshot.ServerTimestampBehavior.ESTIMATE

    // --- User Profile, Private Contact & Addresses ---

    suspend fun ensureUserBootstrapped(
        displayName: String,
        email: String?,
        photoUrl: String?,
        languageCode: String
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val userDoc = db.collection("users").document(uid)
        val contactDoc = userDoc.collection("private").document("contact")
        return try {
            val snap = userDoc.get().await()
            val cleanName = displayName.trim().ifBlank { "Celebration Guest" }.take(80)
            val isBootstrapAdmin = email.equals(MarketplaceConstants.ADMIN_EMAIL, ignoreCase = true)
            if (!snap.exists()) {
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to cleanName,
                    "role" to if (isBootstrapAdmin) "ADMIN" else "CUSTOMER",
                    "preferredLanguage" to languageCode,
                    "photoUrl" to photoUrl?.take(500),
                    "vendorStatus" to "NONE",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                userDoc.set(payload).await()
            }
            val contactSnap = contactDoc.get().await()
            if (!contactSnap.exists()) {
                val contactPayload = mapOf(
                    "userId" to uid,
                    "mobileNumber" to "0000000000",
                    "mobileVerified" to false,
                    "email" to email?.take(160),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                contactDoc.set(contactPayload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userDoc.path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> =
        observeDoc("users/$userId") {
            db.collection("users").document(userId).snapshots()
                .map { snap -> if (snap.exists()) snap.toObject(UserProfile::class.java, estimate) else null }
        }

    fun observePrivateContact(userId: String): Flow<PrivateContact?> =
        observeDoc("users/$userId/private/contact") {
            db.collection("users").document(userId).collection("private").document("contact").snapshots()
                .map { snap -> if (snap.exists()) snap.toObject(PrivateContact::class.java, estimate) else null }
        }

    fun observeAddresses(userId: String): Flow<List<UserAddress>> =
        observeCollection("users/$userId/addresses") {
            db.collection("users").document(userId).collection("addresses").snapshots()
                .map { snap ->
                    snap.toObjects(UserAddress::class.java, estimate)
                        .sortedByDescending { it.defaultAddress }
                }
        }

    suspend fun updateProfileLanguage(userId: String, languageCode: String): Result<Unit> =
        safeMutation(OperationType.UPDATE, "users/$userId") {
            val uid = requireUserId()
            check(uid == userId)
            db.collection("users").document(uid).update(
                mapOf(
                    "preferredLanguage" to languageCode,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun updateDisplayName(userId: String, newName: String, city: String?): Result<Unit> =
        safeMutation(OperationType.UPDATE, "users/$userId") {
            val uid = requireUserId()
            check(uid == userId)
            val clean = newName.trim().take(80)
            require(clean.isNotEmpty()) { "Name cannot be empty" }
            db.collection("users").document(uid).update(
                mapOf(
                    "displayName" to clean,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (!city.isNullOrBlank()) {
                db.collection("users").document(uid).collection("private").document("contact").update(
                    mapOf(
                        "city" to city.trim().take(80),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        }

    suspend fun saveVerifiedMobileNumber(userId: String, mobileNumber: String): Result<Unit> =
        safeMutation(OperationType.UPDATE, "users/$userId/private/contact") {
            val uid = requireUserId()
            check(uid == userId)
            val digits = mobileNumber.filter { it.isDigit() }
            require(digits.length in 10..15) { "Enter a valid mobile number" }
            val ref = db.collection("users").document(uid).collection("private").document("contact")
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "mobileNumber" to digits,
                        "mobileVerified" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(
                    mapOf(
                        "userId" to uid,
                        "mobileNumber" to digits,
                        "mobileVerified" to true,
                        "email" to auth.currentUser?.email,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                ).await()
            }
        }

    suspend fun saveAddress(address: UserAddress): Result<Unit> =
        safeMutation(OperationType.WRITE, "users/${address.userId}/addresses") {
            val uid = requireUserId()
            val col = db.collection("users").document(uid).collection("addresses")
            val docRef = if (address.id.isBlank()) col.document() else col.document(address.id)
            if (address.defaultAddress) {
                val existing = col.get().await()
                for (doc in existing.documents) {
                    if (doc.id != docRef.id && doc.getBoolean("defaultAddress") == true) {
                        doc.reference.update(
                            mapOf("defaultAddress" to false, "updatedAt" to FieldValue.serverTimestamp())
                        ).await()
                    }
                }
            }
            val payload = mapOf(
                "userId" to uid,
                "label" to address.label.trim().ifBlank { "Home" }.take(40),
                "fullName" to address.fullName.trim().take(80),
                "phone" to address.phone.trim().take(20),
                "addressLine" to address.addressLine.trim().take(240),
                "city" to address.city.trim().take(80),
                "pincode" to address.pincode.trim().take(12),
                "defaultAddress" to address.defaultAddress,
                "createdAt" to (address.createdAt ?: FieldValue.serverTimestamp()),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
        }

    suspend fun deleteAddress(addressId: String): Result<Unit> =
        safeMutation(OperationType.DELETE, "users/self/addresses/$addressId") {
            val uid = requireUserId()
            db.collection("users").document(uid).collection("addresses").document(addressId).delete().await()
        }

    // --- Marketplace Catalog Streams (Rule-Aligned Queries) ---

    fun observePlatformConfig(): Flow<PlatformConfig> =
        observeDoc("platform_config/marketplace") {
            db.collection("platform_config").document("marketplace").snapshots()
                .map { snap ->
                    if (snap.exists()) {
                        snap.toObject(PlatformConfig::class.java, estimate) ?: PlatformConfig()
                    } else {
                        PlatformConfig()
                    }
                }
        }

    fun observeCategories(): Flow<List<CategoryItem>> =
        observeCollection("categories") {
            db.collection("categories").snapshots()
                .map { snap -> snap.toObjects(CategoryItem::class.java, estimate).sortedBy { it.sortOrder } }
        }

    fun observeActiveProducts(): Flow<List<Product>> =
        observeCollection("products") {
            db.collection("products").whereEqualTo("active", true).snapshots()
                .map { snap ->
                    snap.toObjects(Product::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeVendorProducts(vendorOwnerId: String): Flow<List<Product>> =
        observeCollection("products") {
            db.collection("products").whereEqualTo("vendorOwnerId", vendorOwnerId).snapshots()
                .map { snap ->
                    snap.toObjects(Product::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeAllProductsForAdmin(): Flow<List<Product>> =
        observeCollection("products") {
            db.collection("products").snapshots()
                .map { snap ->
                    snap.toObjects(Product::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeActiveServices(): Flow<List<EventService>> =
        observeCollection("services") {
            db.collection("services").whereEqualTo("active", true).snapshots()
                .map { snap ->
                    snap.toObjects(EventService::class.java, estimate)
                        .sortedByDescending { it.ratingAvg }
                }
        }

    fun observeVendorServices(vendorOwnerId: String): Flow<List<EventService>> =
        observeCollection("services") {
            db.collection("services").whereEqualTo("vendorOwnerId", vendorOwnerId).snapshots()
                .map { snap ->
                    snap.toObjects(EventService::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeApprovedVendors(): Flow<List<Vendor>> =
        observeCollection("vendors") {
            db.collection("vendors").whereEqualTo("approvalStatus", "APPROVED").snapshots()
                .map { snap -> snap.toObjects(Vendor::class.java, estimate) }
        }

    fun observeMyVendor(ownerId: String): Flow<Vendor?> =
        observeCollection("vendors") {
            db.collection("vendors").whereEqualTo("ownerId", ownerId).snapshots()
                .map { snap -> snap.toObjects(Vendor::class.java, estimate).firstOrNull() }
        }

    fun observeAllVendorsForAdmin(): Flow<List<Vendor>> =
        observeCollection("vendors") {
            db.collection("vendors").snapshots()
                .map { snap ->
                    snap.toObjects(Vendor::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeAllUsersForAdmin(): Flow<List<UserProfile>> =
        observeCollection("users") {
            db.collection("users").snapshots()
                .map { snap ->
                    snap.toObjects(UserProfile::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    // --- Bookings, Orders, Payments, Notifications, Reviews, Complaints ---

    fun observeAvailabilityForService(serviceId: String): Flow<List<AvailabilitySlot>> =
        observeCollection("availability") {
            db.collection("availability").whereEqualTo("serviceId", serviceId).snapshots()
                .map { snap -> snap.toObjects(AvailabilitySlot::class.java, estimate) }
        }

    fun observeAvailabilityForVendor(vendorOwnerId: String): Flow<List<AvailabilitySlot>> =
        observeCollection("availability") {
            db.collection("availability").whereEqualTo("vendorOwnerId", vendorOwnerId).snapshots()
                .map { snap -> snap.toObjects(AvailabilitySlot::class.java, estimate) }
        }

    fun observeCustomerBookings(customerId: String): Flow<List<EventBooking>> =
        observeCollection("bookings") {
            db.collection("bookings").whereEqualTo("customerId", customerId).snapshots()
                .map { snap ->
                    snap.toObjects(EventBooking::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeVendorBookings(vendorOwnerId: String): Flow<List<EventBooking>> =
        observeCollection("bookings") {
            db.collection("bookings").whereEqualTo("vendorOwnerId", vendorOwnerId).snapshots()
                .map { snap ->
                    snap.toObjects(EventBooking::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeAllBookingsForAdmin(): Flow<List<EventBooking>> =
        observeCollection("bookings") {
            db.collection("bookings").snapshots()
                .map { snap ->
                    snap.toObjects(EventBooking::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeCustomerOrders(customerId: String): Flow<List<ProductOrder>> =
        observeCollection("orders") {
            db.collection("orders").whereEqualTo("customerId", customerId).snapshots()
                .map { snap ->
                    snap.toObjects(ProductOrder::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeVendorOrders(vendorOwnerId: String): Flow<List<ProductOrder>> =
        observeCollection("orders") {
            db.collection("orders").whereEqualTo("vendorOwnerId", vendorOwnerId).snapshots()
                .map { snap ->
                    snap.toObjects(ProductOrder::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeCustomerPayments(customerId: String): Flow<List<PaymentRecord>> =
        observeCollection("payments") {
            db.collection("payments").whereEqualTo("customerId", customerId).snapshots()
                .map { snap ->
                    snap.toObjects(PaymentRecord::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeAllPaymentsForAdmin(): Flow<List<PaymentRecord>> =
        observeCollection("payments") {
            db.collection("payments").snapshots()
                .map { snap ->
                    snap.toObjects(PaymentRecord::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeNotifications(recipientId: String): Flow<List<AppNotification>> =
        observeCollection("notifications") {
            db.collection("notifications").whereEqualTo("recipientId", recipientId).snapshots()
                .map { snap ->
                    snap.toObjects(AppNotification::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeReviewsForTarget(targetId: String): Flow<List<ReviewItem>> =
        observeCollection("reviews") {
            db.collection("reviews").whereEqualTo("targetId", targetId).snapshots()
                .map { snap ->
                    snap.toObjects(ReviewItem::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeMyComplaints(userId: String): Flow<List<ComplaintItem>> =
        observeCollection("complaints") {
            db.collection("complaints").whereEqualTo("userId", userId).snapshots()
                .map { snap ->
                    snap.toObjects(ComplaintItem::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    fun observeAllComplaintsForAdmin(): Flow<List<ComplaintItem>> =
        observeCollection("complaints") {
            db.collection("complaints").snapshots()
                .map { snap ->
                    snap.toObjects(ComplaintItem::class.java, estimate)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
        }

    // --- Vendor Registration & Catalog Management ---

    suspend fun registerVendor(
        vendorName: String,
        mobileNumber: String,
        businessName: String,
        city: String,
        location: String,
        serviceCategory: String,
        documentType: String,
        documentImageBase64: String?
    ): Result<String> = safeMutation(OperationType.CREATE, "vendors") {
        val uid = requireUserId()
        val vendorRef = db.collection("vendors").document("vendor_${sanitizeId(uid)}")
        val snap = vendorRef.get().await()
        val payload = mapOf(
            "ownerId" to uid,
            "vendorName" to vendorName.trim().take(80),
            "mobileNumber" to mobileNumber.filter { it.isDigit() }.ifBlank { mobileNumber.trim() }.take(20),
            "businessName" to businessName.trim().take(100),
            "city" to city.trim().take(80),
            "location" to location.trim().take(160),
            "serviceCategory" to serviceCategory.trim().take(60),
            "documentType" to documentType.trim().take(60),
            "documentImageBase64" to documentImageBase64?.take(180_000),
            "approvalStatus" to "PENDING",
            "commissionPercent" to 10.0,
            "createdAt" to (snap.getTimestamp("createdAt") ?: FieldValue.serverTimestamp()),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }
        vendorRef.set(payload).await()

        db.collection("users").document(uid).update(
            mapOf(
                "vendorId" to vendorRef.id,
                "vendorStatus" to "PENDING",
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        sendNotificationInternal(
            recipientId = "ADMIN",
            title = "New Vendor Verification Request",
            message = "$businessName ($city) submitted $documentType for approval.",
            type = "VENDOR_APPROVAL",
            referenceId = vendorRef.id
        )
        vendorRef.id
    }

    suspend fun saveVendorProduct(
        vendor: Vendor,
        existingProductId: String?,
        name: String,
        description: String,
        category: String,
        priceInr: Long,
        stock: Long,
        imageBase64: String?,
        drawableKey: String,
        active: Boolean
    ): Result<Unit> = safeMutation(OperationType.WRITE, "products") {
        val uid = requireUserId()
        require(vendor.ownerId == uid || auth.currentUser?.email.equals(MarketplaceConstants.ADMIN_EMAIL, true))
        val col = db.collection("products")
        val docRef = if (existingProductId.isNullOrBlank()) col.document() else col.document(existingProductId)
        if (existingProductId.isNullOrBlank()) {
            val payload = mapOf(
                "vendorId" to vendor.id,
                "vendorOwnerId" to vendor.ownerId,
                "vendorName" to vendor.businessName,
                "name" to name.trim().take(120),
                "description" to description.trim().take(1000),
                "category" to category,
                "priceInr" to priceInr.coerceAtLeast(1L),
                "stock" to stock.coerceAtLeast(0L),
                "drawableKey" to drawableKey,
                "imageBase64" to imageBase64?.take(180_000),
                "active" to active,
                "ratingAvg" to 4.8,
                "reviewCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            docRef.set(payload).await()
        } else {
            val updates = mutableMapOf<String, Any>(
                "name" to name.trim().take(120),
                "description" to description.trim().take(1000),
                "category" to category,
                "priceInr" to priceInr.coerceAtLeast(1L),
                "stock" to stock.coerceAtLeast(0L),
                "drawableKey" to drawableKey,
                "active" to active,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (imageBase64 != null) updates["imageBase64"] = imageBase64.take(180_000)
            docRef.update(updates).await()
        }
    }

    suspend fun saveVendorService(
        vendor: Vendor,
        existingServiceId: String?,
        title: String,
        eventType: String,
        city: String,
        description: String,
        basePriceInr: Long,
        advancePercent: Long,
        drawableKey: String,
        active: Boolean
    ): Result<Unit> = safeMutation(OperationType.WRITE, "services") {
        val uid = requireUserId()
        require(vendor.ownerId == uid || auth.currentUser?.email.equals(MarketplaceConstants.ADMIN_EMAIL, true))
        val col = db.collection("services")
        val docRef = if (existingServiceId.isNullOrBlank()) col.document() else col.document(existingServiceId)
        if (existingServiceId.isNullOrBlank()) {
            val payload = mapOf(
                "vendorId" to vendor.id,
                "vendorOwnerId" to vendor.ownerId,
                "vendorName" to vendor.businessName,
                "title" to title.trim().take(120),
                "eventType" to eventType,
                "city" to city.trim().take(80),
                "description" to description.trim().take(1200),
                "basePriceInr" to basePriceInr.coerceAtLeast(1L),
                "advancePercent" to advancePercent.coerceIn(10L, 100L),
                "drawableKey" to drawableKey,
                "active" to active,
                "ratingAvg" to 4.9,
                "reviewCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
        } else {
            docRef.update(
                mapOf(
                    "title" to title.trim().take(120),
                    "eventType" to eventType,
                    "city" to city.trim().take(80),
                    "description" to description.trim().take(1200),
                    "basePriceInr" to basePriceInr.coerceAtLeast(1L),
                    "advancePercent" to advancePercent.coerceIn(10L, 100L),
                    "drawableKey" to drawableKey,
                    "active" to active,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    // --- Smart Booking Calendar: Atomic Slot Lock & Anti-Double-Booking Transaction ---

    fun slotDocId(serviceId: String, dateIso: String, slotKey: SlotKey): String =
        "${sanitizeId(serviceId)}_${dateIso}_${slotKey.name}"

    suspend fun lockSlotForCheckout(
        service: EventService,
        dateIso: String,
        slotKey: SlotKey
    ): Result<AvailabilitySlot> = safeMutation(OperationType.WRITE, "availability") {
        val uid = requireUserId()
        val slotId = slotDocId(service.id, dateIso, slotKey)
        val slotRef = db.collection("availability").document(slotId)
        val lockExpiry = Timestamp(Timestamp.now().seconds + 600L, 0)

        db.runTransaction { tx ->
            val snap = tx.get(slotRef)
            val now = Timestamp.now()
            if (snap.exists()) {
                val status = snap.getString("status") ?: "AVAILABLE"
                val lockedBy = snap.getString("lockedByUserId")
                val expiresAt = snap.getTimestamp("lockExpiresAt")
                val isExpiredLock = status == "LOCKED" && expiresAt != null && expiresAt.seconds <= now.seconds
                val canAcquire = status == "AVAILABLE" ||
                    isExpiredLock ||
                    (status == "LOCKED" && lockedBy == uid)
                if (!canAcquire) {
                    throw IllegalStateException("This date and time slot is already booked or pending.")
                }
                tx.update(
                    slotRef,
                    mapOf(
                        "status" to "LOCKED",
                        "lockedByUserId" to uid,
                        "lockExpiresAt" to lockExpiry,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                tx.set(
                    slotRef,
                    mapOf(
                        "serviceId" to service.id,
                        "vendorId" to service.vendorId,
                        "vendorOwnerId" to service.vendorOwnerId,
                        "dateIso" to dateIso,
                        "slotKey" to slotKey.name,
                        "status" to "LOCKED",
                        "lockedByUserId" to uid,
                        "lockExpiresAt" to lockExpiry,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }.await()

        AvailabilitySlot(
            id = slotId,
            serviceId = service.id,
            vendorId = service.vendorId,
            vendorOwnerId = service.vendorOwnerId,
            dateIso = dateIso,
            slotKey = slotKey.name,
            status = "LOCKED",
            lockedByUserId = uid,
            lockExpiresAt = lockExpiry
        )
    }

    suspend fun releaseSlotLock(slotId: String): Result<Unit> =
        safeMutation(OperationType.UPDATE, "availability/$slotId") {
            val uid = requireUserId()
            val slotRef = db.collection("availability").document(slotId)
            db.runTransaction { tx ->
                val snap = tx.get(slotRef)
                if (snap.exists() &&
                    snap.getString("status") == "LOCKED" &&
                    snap.getString("lockedByUserId") == uid
                ) {
                    tx.update(
                        slotRef,
                        mapOf(
                            "status" to "AVAILABLE",
                            "lockedByUserId" to uid,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()
        }

    suspend fun confirmBookingWithPayment(
        service: EventService,
        dateIso: String,
        slotKey: SlotKey,
        customerName: String,
        customerPhone: String,
        venueAddress: String,
        guestCount: Long,
        payFullAmount: Boolean,
        upiApp: String,
        upiId: String
    ): Result<EventBooking> = safeMutation(OperationType.WRITE, "bookings") {
        val uid = requireUserId()
        val slotId = slotDocId(service.id, dateIso, slotKey)
        val slotRef = db.collection("availability").document(slotId)
        val bookingRef = db.collection("bookings").document("bkg_${UUID.randomUUID().toString().take(12)}")
        val paymentRef = db.collection("payments").document("pay_${UUID.randomUUID().toString().take(12)}")

        // Resolve authoritative vendor commission rate
        val vendorSnap = db.collection("vendors").document(service.vendorId).get().await()
        val commissionRate = vendorSnap.getDouble("commissionPercent") ?: 10.0

        val totalAmount = service.basePriceInr
        val advanceAmount = ((totalAmount * service.advancePercent) / 100.0).roundToLong().coerceAtLeast(1L)
        val payNow = if (payFullAmount) totalAmount else advanceAmount
        val remaining = (totalAmount - payNow).coerceAtLeast(0L)
        val commissionAmt = (totalAmount * commissionRate / 100.0).roundToLong()
        val vendorPayout = (totalAmount - commissionAmt).coerceAtLeast(0L)
        val payNowCommission = (payNow * commissionRate / 100.0).roundToLong()
        val payNowVendorNet = (payNow - payNowCommission).coerceAtLeast(0L)
        val paymentStatus = if (remaining == 0L) "FULLY_PAID" else "ADVANCE_PAID"
        val upiRef = "UPI${System.currentTimeMillis().toString().takeLast(8)}${upiId.take(3).uppercase()}"

        db.runTransaction { tx ->
            val slotSnap = tx.get(slotRef)
            val now = Timestamp.now()
            if (slotSnap.exists()) {
                val curStatus = slotSnap.getString("status") ?: "AVAILABLE"
                val lockedBy = slotSnap.getString("lockedByUserId")
                val expiresAt = slotSnap.getTimestamp("lockExpiresAt")
                val expired = curStatus == "LOCKED" && expiresAt != null && expiresAt.seconds <= now.seconds
                val validForUser = curStatus == "AVAILABLE" ||
                    expired ||
                    (curStatus == "LOCKED" && lockedBy == uid)
                if (!validForUser) {
                    throw IllegalStateException("Double-booking blocked: this slot was already reserved.")
                }
                tx.update(
                    slotRef,
                    mapOf(
                        "status" to "BOOKED",
                        "lockedByUserId" to uid,
                        "bookingId" to bookingRef.id,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                tx.set(
                    slotRef,
                    mapOf(
                        "serviceId" to service.id,
                        "vendorId" to service.vendorId,
                        "vendorOwnerId" to service.vendorOwnerId,
                        "dateIso" to dateIso,
                        "slotKey" to slotKey.name,
                        "status" to "BOOKED",
                        "lockedByUserId" to uid,
                        "bookingId" to bookingRef.id,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            tx.set(
                bookingRef,
                mapOf(
                    "customerId" to uid,
                    "customerName" to customerName.trim().ifBlank { "Guest" }.take(80),
                    "customerPhone" to customerPhone.trim().ifBlank { "9999999999" }.take(20),
                    "vendorId" to service.vendorId,
                    "vendorOwnerId" to service.vendorOwnerId,
                    "vendorName" to service.vendorName,
                    "serviceId" to service.id,
                    "serviceTitle" to service.title,
                    "eventType" to service.eventType,
                    "eventDateIso" to dateIso,
                    "slotKey" to slotKey.name,
                    "slotId" to slotId,
                    "venueAddress" to venueAddress.trim().take(280),
                    "guestCount" to guestCount.coerceIn(1L, 50000L),
                    "totalAmountInr" to totalAmount,
                    "advanceAmountInr" to advanceAmount,
                    "paidAmountInr" to payNow,
                    "remainingAmountInr" to remaining,
                    "commissionRatePercent" to commissionRate,
                    "commissionAmountInr" to commissionAmt,
                    "vendorPayoutInr" to vendorPayout,
                    "status" to "CONFIRMED",
                    "paymentStatus" to paymentStatus,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            tx.set(
                paymentRef,
                mapOf(
                    "customerId" to uid,
                    "vendorId" to service.vendorId,
                    "vendorOwnerId" to service.vendorOwnerId,
                    "referenceType" to "BOOKING",
                    "referenceId" to bookingRef.id,
                    "paymentType" to if (payFullAmount) "FULL" else "ADVANCE",
                    "amountInr" to payNow,
                    "commissionAmountInr" to payNowCommission,
                    "vendorNetInr" to payNowVendorNet,
                    "upiTransactionRef" to upiRef,
                    "upiApp" to upiApp,
                    "status" to "SUCCESS",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()

        sendNotificationInternal(
            recipientId = uid,
            title = "Booking Confirmed: ${service.title}",
            message = "Scheduled on $dateIso (${slotKey.label}). Paid ₹$payNow via $upiApp (Ref: $upiRef).",
            type = "BOOKING_CONFIRMED",
            referenceId = bookingRef.id
        )
        sendNotificationInternal(
            recipientId = uid,
            title = "Upcoming Event Reminder",
            message = "${service.eventType} with ${service.vendorName} is locked for $dateIso.",
            type = "EVENT_REMINDER",
            referenceId = bookingRef.id
        )
        sendNotificationInternal(
            recipientId = service.vendorOwnerId,
            title = "New Confirmed Event Booking",
            message = "${customerName.trim()} booked ${service.title} for $dateIso (${slotKey.label}).",
            type = "BOOKING_CONFIRMED",
            referenceId = bookingRef.id
        )

        EventBooking(
            id = bookingRef.id,
            customerId = uid,
            customerName = customerName,
            customerPhone = customerPhone,
            vendorId = service.vendorId,
            vendorOwnerId = service.vendorOwnerId,
            vendorName = service.vendorName,
            serviceId = service.id,
            serviceTitle = service.title,
            eventType = service.eventType,
            eventDateIso = dateIso,
            slotKey = slotKey.name,
            slotId = slotId,
            venueAddress = venueAddress,
            guestCount = guestCount,
            totalAmountInr = totalAmount,
            advanceAmountInr = advanceAmount,
            paidAmountInr = payNow,
            remainingAmountInr = remaining,
            commissionRatePercent = commissionRate,
            commissionAmountInr = commissionAmt,
            vendorPayoutInr = vendorPayout,
            status = "CONFIRMED",
            paymentStatus = paymentStatus
        )
    }

    suspend fun payRemainingBookingBalance(
        booking: EventBooking,
        upiApp: String,
        upiId: String
    ): Result<Unit> = safeMutation(OperationType.UPDATE, "bookings/${booking.id}") {
        val uid = requireUserId()
        require(booking.customerId == uid)
        require(booking.remainingAmountInr > 0L)
        val remaining = booking.remainingAmountInr
        val commissionAmt = (remaining * booking.commissionRatePercent / 100.0).roundToLong()
        val vendorNet = (remaining - commissionAmt).coerceAtLeast(0L)
        val upiRef = "UPI${System.currentTimeMillis().toString().takeLast(8)}${upiId.take(3).uppercase()}"

        val bookingRef = db.collection("bookings").document(booking.id)
        val payRef = db.collection("payments").document("pay_${UUID.randomUUID().toString().take(12)}")

        db.runTransaction { tx ->
            tx.update(
                bookingRef,
                mapOf(
                    "paidAmountInr" to booking.totalAmountInr,
                    "remainingAmountInr" to 0L,
                    "paymentStatus" to "FULLY_PAID",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            tx.set(
                payRef,
                mapOf(
                    "customerId" to uid,
                    "vendorId" to booking.vendorId,
                    "vendorOwnerId" to booking.vendorOwnerId,
                    "referenceType" to "BOOKING",
                    "referenceId" to booking.id,
                    "paymentType" to "REMAINING",
                    "amountInr" to remaining,
                    "commissionAmountInr" to commissionAmt,
                    "vendorNetInr" to vendorNet,
                    "upiTransactionRef" to upiRef,
                    "upiApp" to upiApp,
                    "status" to "SUCCESS",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()

        sendNotificationInternal(
            recipientId = uid,
            title = "Payment Confirmation",
            message = "Remaining ₹$remaining paid for ${booking.serviceTitle} via $upiApp (Ref: $upiRef).",
            type = "PAYMENT_CONFIRMED",
            referenceId = booking.id
        )
        sendNotificationInternal(
            recipientId = booking.vendorOwnerId,
            title = "Final Balance Received",
            message = "Customer paid remaining ₹$remaining for ${booking.serviceTitle} on ${booking.eventDateIso}.",
            type = "PAYMENT_CONFIRMED",
            referenceId = booking.id
        )
    }

    suspend fun cancelBooking(booking: EventBooking, reason: String): Result<Unit> =
        safeMutation(OperationType.UPDATE, "bookings/${booking.id}") {
            val uid = requireUserId()
            val bookingRef = db.collection("bookings").document(booking.id)
            val slotRef = db.collection("availability").document(booking.slotId)
            val refundRef = db.collection("payments").document("ref_${UUID.randomUUID().toString().take(12)}")
            val cleanReason = reason.trim().ifBlank { "Cancelled by user" }.take(300)
            val newPayStatus = if (booking.paidAmountInr > 0L) "REFUND_REQUESTED" else booking.paymentStatus

            db.runTransaction { tx ->
                val slotSnap = tx.get(slotRef)
                tx.update(
                    bookingRef,
                    mapOf(
                        "status" to "CANCELLED",
                        "paymentStatus" to newPayStatus,
                        "cancellationReason" to cleanReason,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (slotSnap.exists()) {
                    tx.update(
                        slotRef,
                        mapOf(
                            "status" to "AVAILABLE",
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                if (booking.paidAmountInr > 0L) {
                    tx.set(
                        refundRef,
                        mapOf(
                            "customerId" to booking.customerId,
                            "vendorId" to booking.vendorId,
                            "vendorOwnerId" to booking.vendorOwnerId,
                            "referenceType" to "BOOKING",
                            "referenceId" to booking.id,
                            "paymentType" to "REFUND",
                            "amountInr" to booking.paidAmountInr,
                            "commissionAmountInr" to 0L,
                            "vendorNetInr" to 0L,
                            "upiTransactionRef" to "REF${System.currentTimeMillis().toString().takeLast(8)}",
                            "upiApp" to "UPI Refund",
                            "status" to "REFUND_PENDING",
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()

            sendNotificationInternal(
                recipientId = booking.customerId,
                title = "Booking Cancelled",
                message = "${booking.serviceTitle} (${booking.eventDateIso}) cancelled. Refund status: $newPayStatus.",
                type = "CANCELLATION",
                referenceId = booking.id
            )
            if (booking.vendorOwnerId != uid) {
                sendNotificationInternal(
                    recipientId = booking.vendorOwnerId,
                    title = "Booking Cancelled & Slot Released",
                    message = "${booking.eventDateIso} (${booking.slotKey}) for ${booking.serviceTitle} is open again.",
                    type = "CANCELLATION",
                    referenceId = booking.id
                )
            }
        }

    suspend fun toggleVendorSlotBlock(
        service: EventService,
        dateIso: String,
        slotKey: SlotKey,
        block: Boolean
    ): Result<Unit> = safeMutation(OperationType.WRITE, "availability") {
        val uid = requireUserId()
        require(service.vendorOwnerId == uid)
        val slotId = slotDocId(service.id, dateIso, slotKey)
        val slotRef = db.collection("availability").document(slotId)
        db.runTransaction { tx ->
            val snap = tx.get(slotRef)
            val newStatus = if (block) "BLOCKED" else "AVAILABLE"
            if (snap.exists()) {
                val cur = snap.getString("status") ?: "AVAILABLE"
                if (cur == "BOOKED") throw IllegalStateException("Cannot override a confirmed booking.")
                tx.update(
                    slotRef,
                    mapOf(
                        "status" to newStatus,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                tx.set(
                    slotRef,
                    mapOf(
                        "serviceId" to service.id,
                        "vendorId" to service.vendorId,
                        "vendorOwnerId" to service.vendorOwnerId,
                        "dateIso" to dateIso,
                        "slotKey" to slotKey.name,
                        "status" to newStatus,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }.await()
    }

    // --- Cart Checkout & Product Orders ---

    suspend fun placeProductOrders(
        cartEntries: List<CartEntry>,
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        upiApp: String,
        upiId: String
    ): Result<List<String>> = safeMutation(OperationType.WRITE, "orders") {
        val uid = requireUserId()
        require(cartEntries.isNotEmpty()) { "Cart is empty" }
        val groupedByVendor = cartEntries.groupBy { it.product.vendorId }
        val orderIds = mutableListOf<String>()

        for ((vendorId, entries) in groupedByVendor) {
            val first = entries.first().product
            val vendorSnap = db.collection("vendors").document(vendorId).get().await()
            val commissionRate = vendorSnap.getDouble("commissionPercent") ?: 10.0

            val orderRef = db.collection("orders").document("ord_${UUID.randomUUID().toString().take(12)}")
            val paymentRef = db.collection("payments").document("pay_${UUID.randomUUID().toString().take(12)}")
            val upiRef = "UPI${System.currentTimeMillis().toString().takeLast(8)}${upiId.take(3).uppercase()}"

            val subtotal = entries.sumOf { it.product.priceInr * it.quantity }
            val commissionAmt = (subtotal * commissionRate / 100.0).roundToLong()
            val vendorPayout = (subtotal - commissionAmt).coerceAtLeast(0L)

            db.runTransaction { tx ->
                val itemSnapshots = entries.map { entry ->
                    val pRef = db.collection("products").document(entry.product.id)
                    val pSnap = tx.get(pRef)
                    val curStock = pSnap.getLong("stock") ?: 0L
                    if (curStock < entry.quantity) {
                        throw IllegalStateException("Insufficient stock for ${entry.product.name}")
                    }
                    Triple(pRef, curStock - entry.quantity, entry)
                }

                for ((pRef, nextStock, _) in itemSnapshots) {
                    tx.update(
                        pRef,
                        mapOf(
                            "stock" to nextStock,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }

                val orderItemsList = entries.map { entry ->
                    mapOf(
                        "productId" to entry.product.id,
                        "productName" to entry.product.name,
                        "category" to entry.product.category,
                        "quantity" to entry.quantity.toLong(),
                        "unitPriceInr" to entry.product.priceInr
                    )
                }

                tx.set(
                    orderRef,
                    mapOf(
                        "customerId" to uid,
                        "customerName" to customerName.trim().ifBlank { "Guest" }.take(80),
                        "customerPhone" to customerPhone.trim().ifBlank { "9999999999" }.take(20),
                        "deliveryAddress" to deliveryAddress.trim().take(280),
                        "vendorId" to vendorId,
                        "vendorOwnerId" to first.vendorOwnerId,
                        "vendorName" to first.vendorName,
                        "items" to orderItemsList,
                        "subtotalInr" to subtotal,
                        "commissionRatePercent" to commissionRate,
                        "commissionAmountInr" to commissionAmt,
                        "vendorPayoutInr" to vendorPayout,
                        "totalAmountInr" to subtotal,
                        "paidAmountInr" to subtotal,
                        "remainingAmountInr" to 0L,
                        "paymentMethod" to upiApp,
                        "paymentStatus" to "FULLY_PAID",
                        "orderStatus" to "PLACED",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                tx.set(
                    paymentRef,
                    mapOf(
                        "customerId" to uid,
                        "vendorId" to vendorId,
                        "vendorOwnerId" to first.vendorOwnerId,
                        "referenceType" to "ORDER",
                        "referenceId" to orderRef.id,
                        "paymentType" to "FULL",
                        "amountInr" to subtotal,
                        "commissionAmountInr" to commissionAmt,
                        "vendorNetInr" to vendorPayout,
                        "upiTransactionRef" to upiRef,
                        "upiApp" to upiApp,
                        "status" to "SUCCESS",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            orderIds.add(orderRef.id)
            sendNotificationInternal(
                recipientId = uid,
                title = "Order Placed with ${first.vendorName}",
                message = "Paid ₹$subtotal via $upiApp (Ref: $upiRef). Track status in Bookings.",
                type = "ORDER_UPDATE",
                referenceId = orderRef.id
            )
            sendNotificationInternal(
                recipientId = first.vendorOwnerId,
                title = "New Product Order Received",
                message = "${customerName.trim()} ordered ${entries.size} item(s) worth ₹$subtotal.",
                type = "ORDER_UPDATE",
                referenceId = orderRef.id
            )
        }
        orderIds
    }

    suspend fun updateOrderStatus(order: ProductOrder, nextStatus: String): Result<Unit> =
        safeMutation(OperationType.UPDATE, "orders/${order.id}") {
            requireUserId()
            db.collection("orders").document(order.id).update(
                mapOf(
                    "orderStatus" to nextStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            sendNotificationInternal(
                recipientId = order.customerId,
                title = "Order Update: $nextStatus",
                message = "Your order from ${order.vendorName} is now $nextStatus.",
                type = "ORDER_UPDATE",
                referenceId = order.id
            )
        }

    // --- Reviews, Notifications & Complaints ---

    suspend fun submitReview(
        userName: String,
        targetType: String,
        targetId: String,
        rating: Int,
        comment: String
    ): Result<Unit> = safeMutation(OperationType.CREATE, "reviews") {
        val uid = requireUserId()
        val revRef = db.collection("reviews").document()
        revRef.set(
            mapOf(
                "userId" to uid,
                "userName" to userName.trim().ifBlank { "Verified Customer" }.take(80),
                "targetType" to targetType,
                "targetId" to targetId,
                "rating" to rating.coerceIn(1, 5).toLong(),
                "comment" to comment.trim().take(500),
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> =
        safeMutation(OperationType.UPDATE, "notifications/$notificationId") {
            requireUserId()
            db.collection("notifications").document(notificationId).update("readFlag", true).await()
        }

    suspend fun submitComplaint(
        userName: String,
        subject: String,
        description: String,
        referenceId: String
    ): Result<Unit> = safeMutation(OperationType.CREATE, "complaints") {
        val uid = requireUserId()
        val ref = db.collection("complaints").document()
        ref.set(
            mapOf(
                "userId" to uid,
                "userName" to userName.trim().ifBlank { "Customer" }.take(80),
                "subject" to subject.trim().take(120),
                "description" to description.trim().take(1000),
                "referenceId" to referenceId.trim().take(128),
                "status" to "OPEN",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    // --- Admin Controls ---

    suspend fun approveOrRejectVendor(
        vendor: Vendor,
        approve: Boolean,
        commissionPercent: Double,
        rejectionReason: String?
    ): Result<Unit> = safeMutation(OperationType.UPDATE, "vendors/${vendor.id}") {
        requireUserId()
        val newStatus = if (approve) "APPROVED" else "REJECTED"
        db.collection("vendors").document(vendor.id).update(
            mapOf(
                "approvalStatus" to newStatus,
                "commissionPercent" to commissionPercent.coerceIn(0.0, 50.0),
                "rejectionReason" to (rejectionReason?.trim()?.take(300) ?: ""),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        db.collection("users").document(vendor.ownerId).update(
            mapOf(
                "role" to if (approve) "VENDOR" else "CUSTOMER",
                "vendorStatus" to newStatus,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        sendNotificationInternal(
            recipientId = vendor.ownerId,
            title = if (approve) "Vendor Approved!" else "Vendor Application Update",
            message = if (approve) {
                "${vendor.businessName} is now live on M Mangalam Events (Fee: $commissionPercent%)."
            } else {
                "${vendor.businessName} verification needs review: ${rejectionReason ?: "Check documents"}."
            },
            type = "VENDOR_APPROVAL",
            referenceId = vendor.id
        )
    }

    suspend fun updatePlatformCommission(percent: Double): Result<Unit> =
        safeMutation(OperationType.WRITE, "platform_config/marketplace") {
            val uid = requireUserId()
            db.collection("platform_config").document("marketplace").set(
                mapOf(
                    "defaultCommissionPercent" to percent.coerceIn(0.0, 50.0),
                    "updatedBy" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun updateUserRole(userId: String, role: String): Result<Unit> =
        safeMutation(OperationType.UPDATE, "users/$userId") {
            requireUserId()
            db.collection("users").document(userId).update(
                mapOf(
                    "role" to role,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun toggleProductActive(productId: String, active: Boolean): Result<Unit> =
        safeMutation(OperationType.UPDATE, "products/$productId") {
            requireUserId()
            db.collection("products").document(productId).update(
                mapOf(
                    "active" to active,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun markRefundProcessed(payment: PaymentRecord): Result<Unit> =
        safeMutation(OperationType.UPDATE, "payments/${payment.id}") {
            requireUserId()
            db.collection("payments").document(payment.id).update(
                mapOf(
                    "status" to "REFUNDED",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (payment.referenceType == "BOOKING") {
                db.collection("bookings").document(payment.referenceId).update(
                    mapOf(
                        "paymentStatus" to "REFUNDED",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            sendNotificationInternal(
                recipientId = payment.customerId,
                title = "Refund Completed",
                message = "₹${payment.amountInr} refunded to your UPI account (Ref: ${payment.upiTransactionRef}).",
                type = "PAYMENT_CONFIRMED",
                referenceId = payment.referenceId
            )
        }

    suspend fun resolveComplaint(complaintId: String, status: String, adminNote: String): Result<Unit> =
        safeMutation(OperationType.UPDATE, "complaints/$complaintId") {
            requireUserId()
            db.collection("complaints").document(complaintId).update(
                mapOf(
                    "status" to status,
                    "adminNote" to adminNote.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    // --- Admin Starter Catalog Seeding (Runs only when Admin logs in & catalog is empty) ---

    suspend fun seedMarketplaceIfEmpty(): Result<Unit> =
        safeMutation(OperationType.WRITE, "seed") {
            val uid = requireUserId()
            val email = auth.currentUser?.email
            if (!email.equals(MarketplaceConstants.ADMIN_EMAIL, ignoreCase = true)) return@safeMutation

            val existingProducts = db.collection("products").limit(1).get().await()
            if (!existingProducts.isEmpty) return@safeMutation

            db.collection("platform_config").document("marketplace").set(
                mapOf(
                    "defaultCommissionPercent" to 10.0,
                    "updatedBy" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val catSeeds = listOf(
                Triple("cat_clothes", "Clothes", "PRODUCT"),
                Triple("cat_shoes", "Shoes", "PRODUCT"),
                Triple("cat_jewellery", "Jewellery", "PRODUCT"),
                Triple("cat_gifts", "Gifts", "PRODUCT"),
                Triple("cat_decor", "Decorations", "PRODUCT"),
                Triple("cat_wedding", "Wedding", "EVENT"),
                Triple("cat_engagement", "Engagement", "EVENT"),
                Triple("cat_birthday", "Birthday", "EVENT"),
                Triple("cat_anniversary", "Anniversary", "EVENT"),
                Triple("cat_babyshower", "Baby shower", "EVENT"),
                Triple("cat_party", "Party", "EVENT")
            )
            catSeeds.forEachIndexed { idx, (id, name, kind) ->
                db.collection("categories").document(id).set(
                    mapOf(
                        "name" to name,
                        "kind" to kind,
                        "commissionPercent" to 10.0,
                        "active" to true,
                        "sortOrder" to idx.toLong(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            val vendorSeeds = listOf(
                mapOf(
                    "id" to "vendor_royal_mandap",
                    "ownerId" to uid,
                    "vendorName" to "Mauli Rajwadkar",
                    "mobileNumber" to "9822011223",
                    "businessName" to "Rajwada Royal Mandaps",
                    "city" to "Pune",
                    "location" to "Deccan Gymkhana",
                    "serviceCategory" to "Wedding",
                    "documentType" to "GST Certificate",
                    "approvalStatus" to "APPROVED",
                    "commissionPercent" to 10.0
                ),
                mapOf(
                    "id" to "vendor_shagun_atelier",
                    "ownerId" to uid,
                    "vendorName" to "Kaveri Deshmukh",
                    "mobileNumber" to "9765411009",
                    "businessName" to "Shagun Heritage Creations",
                    "city" to "Nashik",
                    "location" to "Saraf Bazaar",
                    "serviceCategory" to "Attire & Jewellery",
                    "documentType" to "Shop Act License",
                    "approvalStatus" to "APPROVED",
                    "commissionPercent" to 10.0
                )
            )
            for (v in vendorSeeds) {
                val vid = v["id"] as String
                db.collection("vendors").document(vid).set(
                    v.filterKeys { it != "id" } + mapOf(
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            val productSeeds = listOf(
                mapOf(
                    "id" to "prod_paithani_lehenga",
                    "vendorId" to "vendor_shagun_atelier",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Shagun Heritage Creations",
                    "name" to "Royal Paithani Silk Bridal Ensemble",
                    "description" to "Handwoven gold-zari Paithani silk bridal attire crafted by Yeola artisans.",
                    "category" to "Clothes",
                    "priceInr" to 24500L,
                    "stock" to 8L,
                    "drawableKey" to "jewellery"
                ),
                mapOf(
                    "id" to "prod_kundan_haar",
                    "vendorId" to "vendor_shagun_atelier",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Shagun Heritage Creations",
                    "name" to "Maharani Kundan & Pearl Haar Set",
                    "description" to "22k gold-plated bridal Kundan choker with matching jhumkas and maang tikka.",
                    "category" to "Jewellery",
                    "priceInr" to 6800L,
                    "stock" to 14L,
                    "drawableKey" to "jewellery"
                ),
                mapOf(
                    "id" to "prod_kolhapuri_mojari",
                    "vendorId" to "vendor_shagun_atelier",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Shagun Heritage Creations",
                    "name" to "Zari Embroidered Groom Mojari",
                    "description" to "Cushioned velvet wedding mojari with antique gold dabka embroidery.",
                    "category" to "Shoes",
                    "priceInr" to 2499L,
                    "stock" to 20L,
                    "drawableKey" to "decor"
                ),
                mapOf(
                    "id" to "prod_shagun_hamper",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Rajwada Royal Mandaps",
                    "name" to "Gold-Foiled Dry Fruit Shagun Box",
                    "description" to "Luxury velvet & brass clasp wedding return gift hamper with saffron almonds.",
                    "category" to "Gifts",
                    "priceInr" to 1250L,
                    "stock" to 60L,
                    "drawableKey" to "decor"
                ),
                mapOf(
                    "id" to "prod_brass_urli",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Rajwada Royal Mandaps",
                    "name" to "Handcrafted Brass Urli & Diya Set",
                    "description" to "Auspicious lotus brass urli bowl with 12 hammered floating diyas & marigold toran.",
                    "category" to "Decorations",
                    "priceInr" to 3200L,
                    "stock" to 30L,
                    "drawableKey" to "decor"
                )
            )
            for (p in productSeeds) {
                val pid = p["id"] as String
                db.collection("products").document(pid).set(
                    p.filterKeys { it != "id" } + mapOf(
                        "active" to true,
                        "ratingAvg" to 4.9,
                        "reviewCount" to 12L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            val serviceSeeds = listOf(
                mapOf(
                    "id" to "svc_royal_wedding",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Rajwada Royal Mandaps",
                    "title" to "Rajwada Gold Marigold Mandap & Stage",
                    "eventType" to "Wedding",
                    "city" to "Pune",
                    "description" to "Grand carved golden mandap, fresh marigold-jasmine floral ceiling, warm chandeliers & royal seating.",
                    "basePriceInr" to 95000L,
                    "advancePercent" to 30L,
                    "drawableKey" to "wedding"
                ),
                mapOf(
                    "id" to "svc_engagement_gala",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Rajwada Royal Mandaps",
                    "title" to "Sagai Ring Ceremony & Floral Arch",
                    "eventType" to "Engagement",
                    "city" to "Nashik",
                    "description" to "Velvet backdrop, golden ring-ceremony podium, LED fairy canopy & welcome brass diyas.",
                    "basePriceInr" to 42000L,
                    "advancePercent" to 30L,
                    "drawableKey" to "wedding"
                ),
                mapOf(
                    "id" to "svc_birthday_bash",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Rajwada Royal Mandaps",
                    "title" to "Golden Jubilee & Royal Birthday Setup",
                    "eventType" to "Birthday",
                    "city" to "Mumbai",
                    "description" to "Custom theme stage, champagne balloon arch, photo booth & sound lighting.",
                    "basePriceInr" to 18500L,
                    "advancePercent" to 25L,
                    "drawableKey" to "decor"
                ),
                mapOf(
                    "id" to "svc_anniversary_soiree",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Rajwada Royal Mandaps",
                    "title" to "Candlelight Golden Anniversary Decor",
                    "eventType" to "Anniversary",
                    "city" to "Pune",
                    "description" to "Intimate candlelit floral pavilion, brass lanterns, and acoustic live music arrangement.",
                    "basePriceInr" to 28000L,
                    "advancePercent" to 30L,
                    "drawableKey" to "hero"
                ),
                mapOf(
                    "id" to "svc_baby_shower",
                    "vendorId" to "vendor_shagun_atelier",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Shagun Heritage Creations",
                    "title" to "Traditional Dohale Jevan Floral Swing",
                    "eventType" to "Baby shower",
                    "city" to "Kolhapur",
                    "description" to "Auspicious flower-bedecked jhula swing, traditional rangoli welcome & brass thali styling.",
                    "basePriceInr" to 22000L,
                    "advancePercent" to 25L,
                    "drawableKey" to "decor"
                ),
                mapOf(
                    "id" to "svc_party_night",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "vendorName" to "Rajwada Royal Mandaps",
                    "title" to "Sangeet & Cocktail DJ Lounge Setup",
                    "eventType" to "Party",
                    "city" to "Nagpur",
                    "description" to "LED dance floor, gold-accent lounge seating, fog effects & professional DJ console.",
                    "basePriceInr" to 35000L,
                    "advancePercent" to 30L,
                    "drawableKey" to "hero"
                )
            )
            for (s in serviceSeeds) {
                val sid = s["id"] as String
                db.collection("services").document(sid).set(
                    s.filterKeys { it != "id" } + mapOf(
                        "active" to true,
                        "ratingAvg" to 4.9,
                        "reviewCount" to 18L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            // Seed sample booked & pending slots on upcoming dates so the Smart Calendar shows Red & Orange immediately
            val sampleBookedSlotId = "svc_royal_wedding_2026-11-28_EVENING"
            db.collection("availability").document(sampleBookedSlotId).set(
                mapOf(
                    "serviceId" to "svc_royal_wedding",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "dateIso" to "2026-11-28",
                    "slotKey" to "EVENING",
                    "status" to "BOOKED",
                    "lockedByUserId" to uid,
                    "bookingId" to "sample_booked_1",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val samplePendingSlotId = "svc_royal_wedding_2026-11-29_MORNING"
            db.collection("availability").document(samplePendingSlotId).set(
                mapOf(
                    "serviceId" to "svc_royal_wedding",
                    "vendorId" to "vendor_royal_mandap",
                    "vendorOwnerId" to uid,
                    "dateIso" to "2026-11-29",
                    "slotKey" to "MORNING",
                    "status" to "PENDING",
                    "lockedByUserId" to uid,
                    "bookingId" to "sample_pending_1",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    // --- Internal Helpers ---

    private suspend fun sendNotificationInternal(
        recipientId: String,
        title: String,
        message: String,
        type: String,
        referenceId: String
    ) {
        try {
            db.collection("notifications").document().set(
                mapOf(
                    "recipientId" to recipientId,
                    "title" to title.take(120),
                    "message" to message.take(500),
                    "type" to type.take(40),
                    "referenceId" to referenceId.take(128),
                    "readFlag" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "notifications")
        }
    }

    private fun <T> observeDoc(path: String, block: () -> Flow<T>): Flow<T> = flow {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank()) throw IllegalStateException("Unauthenticated")
        emitAll(
            block().catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.GET, path)
                }
                throw error
            }
        )
    }

    private fun <T> observeCollection(path: String, block: () -> Flow<T>): Flow<T> = flow {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank()) throw IllegalStateException("Unauthenticated")
        emitAll(
            block().catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
        )
    }

    private suspend fun <T> safeMutation(
        opType: OperationType,
        path: String,
        block: suspend () -> T
    ): Result<T> = try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, opType, path)
        Result.failure(e)
    }
}
