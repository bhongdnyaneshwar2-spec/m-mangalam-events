package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// M Mangalam Events — Obsidian Black & Royal Gold Luxury Palette
val ObsidianBlack = Color(0xFF0A0A0C)
val VelvetSurface = Color(0xFF141418)
val OnyxCard = Color(0xFF1C1C22)
val ElevatedCharcoal = Color(0xFF25252D)
val HairlineGoldBorder = Color(0xFF3A3120)

val RoyalGold = Color(0xFFD4AF37)
val ChampagneGold = Color(0xFFF3E5AB)
val BurnishedGold = Color(0xFFB58E24)
val DeepBronze = Color(0xFF5C4612)
val WarmMarigold = Color(0xFFE69F24)
val CrimsonSaffron = Color(0xFF8B2635)

val IvoryText = Color(0xFFF8F5EE)
val MutedChampagne = Color(0xFFB8B0A0)
val SubtleSlate = Color(0xFF7D786E)

// Smart Booking Calendar & Status Tokens
val AvailableGreen = Color(0xFF2ECC71)
val AvailableGreenBg = Color(0xFF132D1F)
val BookedRed = Color(0xFFE74C3C)
val BookedRedBg = Color(0xFF331616)
val PendingOrange = Color(0xFFF39C12)
val PendingOrangeBg = Color(0xFF33240E)
val LockedBlue = Color(0xFF5DADE2)
val InfoIndigoBg = Color(0xFF162533)
