package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.MarketplaceRepository
import com.example.data.model.AppNotification
import com.example.data.model.AvailabilitySlot
import com.example.data.model.CartEntry
import com.example.data.model.CategoryItem
import com.example.data.model.ComplaintItem
import com.example.data.model.EventBooking
import com.example.data.model.EventService
import com.example.data.model.MarketplaceConstants
import com.example.data.model.PaymentRecord
import com.example.data.model.PlatformConfig
import com.example.data.model.PrivateContact
import com.example.data.model.Product
import com.example.data.model.ProductOrder
import com.example.data.model.ReviewItem
import com.example.data.model.SlotKey
import com.example.data.model.UiState
import com.example.data.model.UserAddress
import com.example.data.model.UserProfile
import com.example.data.model.Vendor
import com.example.i18n.AppLanguage
import com.example.i18n.LanguagePreferences
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MarketplaceViewModel(
    private val repository: MarketplaceRepository,
    private val languagePreferences: LanguagePreferences,
    val currentUserId: String,
    val currentUserEmail: String?,
    val currentUserName: String,
    private val currentPhotoUrl: String?
) : ViewModel() {

    val isBootstrapAdmin: Boolean =
        currentUserEmail.equals(MarketplaceConstants.ADMIN_EMAIL, ignoreCase = true)

    val language: StateFlow<AppLanguage> = languagePreferences.languageFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppLanguage.EN)

    val userProfile: StateFlow<UserProfile?> = repository.observeUserProfile(currentUserId)
        .catch { handleStreamCatch("userProfile", it); emit(null) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val privateContact: StateFlow<PrivateContact?> = repository.observePrivateContact(currentUserId)
        .catch { handleStreamCatch("privateContact", it); emit(null) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val addresses: StateFlow<List<UserAddress>> = repository.observeAddresses(currentUserId)
        .catch { handleStreamCatch("addresses", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val platformConfig: StateFlow<PlatformConfig> = repository.observePlatformConfig()
        .catch { handleStreamCatch("platformConfig", it); emit(PlatformConfig()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), PlatformConfig())

    val categories: StateFlow<List<CategoryItem>> = repository.observeCategories()
        .catch { handleStreamCatch("categories", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val productsState: StateFlow<UiState<List<Product>>> = repository.observeActiveProducts()
        .toUiState("products")

    val servicesState: StateFlow<UiState<List<EventService>>> = repository.observeActiveServices()
        .toUiState("services")

    val approvedVendors: StateFlow<List<Vendor>> = repository.observeApprovedVendors()
        .catch { handleStreamCatch("approvedVendors", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val myVendor: StateFlow<Vendor?> = repository.observeMyVendor(currentUserId)
        .catch { handleStreamCatch("myVendor", it); emit(null) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val vendorProducts: StateFlow<List<Product>> = repository.observeVendorProducts(currentUserId)
        .catch { handleStreamCatch("vendorProducts", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val vendorServices: StateFlow<List<EventService>> = repository.observeVendorServices(currentUserId)
        .catch { handleStreamCatch("vendorServices", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val vendorBookings: StateFlow<List<EventBooking>> = repository.observeVendorBookings(currentUserId)
        .catch { handleStreamCatch("vendorBookings", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val vendorOrders: StateFlow<List<ProductOrder>> = repository.observeVendorOrders(currentUserId)
        .catch { handleStreamCatch("vendorOrders", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val vendorAvailability: StateFlow<List<AvailabilitySlot>> = repository.observeAvailabilityForVendor(currentUserId)
        .catch { handleStreamCatch("vendorAvailability", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val customerBookings: StateFlow<UiState<List<EventBooking>>> = repository.observeCustomerBookings(currentUserId)
        .toUiState("customerBookings")

    val customerOrders: StateFlow<UiState<List<ProductOrder>>> = repository.observeCustomerOrders(currentUserId)
        .toUiState("customerOrders")

    val customerPayments: StateFlow<List<PaymentRecord>> = repository.observeCustomerPayments(currentUserId)
        .catch { handleStreamCatch("customerPayments", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.observeNotifications(currentUserId)
        .catch { handleStreamCatch("notifications", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val myComplaints: StateFlow<List<ComplaintItem>> = repository.observeMyComplaints(currentUserId)
        .catch { handleStreamCatch("myComplaints", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Admin streams (active only when admin)
    private val isAdminStream = userProfile.map { it?.role == "ADMIN" || isBootstrapAdmin }

    val adminVendors: StateFlow<List<Vendor>> = isAdminStream.flatMapLatest { admin ->
        if (admin) repository.observeAllVendorsForAdmin() else flowOf(emptyList())
    }.catch { handleStreamCatch("adminVendors", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminUsers: StateFlow<List<UserProfile>> = isAdminStream.flatMapLatest { admin ->
        if (admin) repository.observeAllUsersForAdmin() else flowOf(emptyList())
    }.catch { handleStreamCatch("adminUsers", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminProducts: StateFlow<List<Product>> = isAdminStream.flatMapLatest { admin ->
        if (admin) repository.observeAllProductsForAdmin() else flowOf(emptyList())
    }.catch { handleStreamCatch("adminProducts", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminBookings: StateFlow<List<EventBooking>> = isAdminStream.flatMapLatest { admin ->
        if (admin) repository.observeAllBookingsForAdmin() else flowOf(emptyList())
    }.catch { handleStreamCatch("adminBookings", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminPayments: StateFlow<List<PaymentRecord>> = isAdminStream.flatMapLatest { admin ->
        if (admin) repository.observeAllPaymentsForAdmin() else flowOf(emptyList())
    }.catch { handleStreamCatch("adminPayments", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminComplaints: StateFlow<List<ComplaintItem>> = isAdminStream.flatMapLatest { admin ->
        if (admin) repository.observeAllComplaintsForAdmin() else flowOf(emptyList())
    }.catch { handleStreamCatch("adminComplaints", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminNotifications: StateFlow<List<AppNotification>> = isAdminStream.flatMapLatest { admin ->
        if (admin) repository.observeNotifications("ADMIN") else flowOf(emptyList())
    }.catch { handleStreamCatch("adminNotifications", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Active Service Calendar & Reviews
    private val selectedServiceId = MutableStateFlow<String?>(null)
    val selectedServiceAvailability: StateFlow<List<AvailabilitySlot>> = selectedServiceId.flatMapLatest { sid ->
        if (sid.isNullOrBlank()) flowOf(emptyList()) else repository.observeAvailabilityForService(sid)
    }.catch { handleStreamCatch("serviceAvailability", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val selectedReviewTargetId = MutableStateFlow<String?>(null)
    val activeTargetReviews: StateFlow<List<ReviewItem>> = selectedReviewTargetId.flatMapLatest { tid ->
        if (tid.isNullOrBlank()) flowOf(emptyList()) else repository.observeReviewsForTarget(tid)
    }.catch { handleStreamCatch("reviews", it); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Cart & Interactive Checkout State
    private val _cart = MutableStateFlow<List<CartEntry>>(emptyList())
    val cart: StateFlow<List<CartEntry>> = _cart.asStateFlow()

    private val _lockedSlot = MutableStateFlow<AvailabilitySlot?>(null)
    val lockedSlot: StateFlow<AvailabilitySlot?> = _lockedSlot.asStateFlow()

    private val _pendingOtpCode = MutableStateFlow<String?>(null)
    val pendingOtpCode: StateFlow<String?> = _pendingOtpCode.asStateFlow()

    private val _pendingOtpMobile = MutableStateFlow<String>("")
    val pendingOtpMobile: StateFlow<String> = _pendingOtpMobile.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureUserBootstrapped(
                displayName = currentUserName,
                email = currentUserEmail,
                photoUrl = currentPhotoUrl,
                languageCode = language.value.code
            )
            if (isBootstrapAdmin) {
                repository.seedMarketplaceIfEmpty()
            }
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch {
            languagePreferences.setLanguage(lang)
            repository.updateProfileLanguage(currentUserId, lang.code)
        }
    }

    fun watchServiceCalendar(serviceId: String) {
        selectedServiceId.value = serviceId
        selectedReviewTargetId.value = serviceId
    }

    fun watchProductReviews(productId: String) {
        selectedReviewTargetId.value = productId
    }

    // --- Cart Operations ---

    fun addToCart(product: Product) {
        if (product.stock <= 0L) {
            showMessage("This item is currently out of stock.")
            return
        }
        _cart.update { items ->
            val existing = items.firstOrNull { it.product.id == product.id }
            if (existing != null) {
                if (existing.quantity >= product.stock) {
                    showMessage("Maximum available stock reached.")
                    items
                } else {
                    items.map {
                        if (it.product.id == product.id) it.copy(quantity = it.quantity + 1) else it
                    }
                }
            } else {
                items + CartEntry(product, 1)
            }
        }
        showMessage("Added ${product.name} to bag.")
    }

    fun updateCartQuantity(productId: String, delta: Int) {
        _cart.update { items ->
            items.mapNotNull { entry ->
                if (entry.product.id != productId) entry
                else {
                    val next = entry.quantity + delta
                    when {
                        next <= 0 -> null
                        next > entry.product.stock -> entry
                        else -> entry.copy(quantity = next)
                    }
                }
            }
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    // --- OTP Mobile Verification & Profile ---

    fun generateMobileOtp(mobile: String) {
        val digits = mobile.filter { it.isDigit() }
        if (digits.length < 10) {
            showMessage("Please enter a valid 10-digit mobile number.")
            return
        }
        val code = (100000..999999).random().toString()
        _pendingOtpMobile.value = digits
        _pendingOtpCode.value = code
        showMessage("Verification OTP: $code (valid for this session)")
    }

    fun verifyMobileOtp(enteredCode: String) {
        val expected = _pendingOtpCode.value
        val mobile = _pendingOtpMobile.value
        if (expected.isNullOrBlank() || enteredCode.trim() != expected) {
            showMessage("Invalid OTP code. Please check and retry.")
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            repository.saveVerifiedMobileNumber(currentUserId, mobile)
                .onSuccess {
                    _pendingOtpCode.value = null
                    showMessage("Mobile number +91 $mobile verified!")
                }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to save mobile") }
            _isBusy.value = false
        }
    }

    fun updateProfileName(name: String, city: String) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.updateDisplayName(currentUserId, name, city)
                .onSuccess { showMessage("Profile updated.") }
                .onFailure { showMessage(it.localizedMessage ?: "Update failed") }
            _isBusy.value = false
        }
    }

    fun saveAddress(address: UserAddress) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.saveAddress(address.copy(userId = currentUserId))
                .onSuccess { showMessage("Address saved.") }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to save address") }
            _isBusy.value = false
        }
    }

    fun deleteAddress(addressId: String) {
        viewModelScope.launch {
            repository.deleteAddress(addressId)
                .onSuccess { showMessage("Address removed.") }
                .onFailure { showMessage(it.localizedMessage ?: "Delete failed") }
        }
    }

    // --- Smart Booking Flow ---

    fun lockSlot(service: EventService, dateIso: String, slotKey: SlotKey, onLocked: () -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.lockSlotForCheckout(service, dateIso, slotKey)
                .onSuccess { slot ->
                    _lockedSlot.value = slot
                    onLocked()
                }
                .onFailure { showMessage(it.localizedMessage ?: "Slot unavailable") }
            _isBusy.value = false
        }
    }

    fun releaseCurrentSlotLock() {
        val slot = _lockedSlot.value ?: return
        _lockedSlot.value = null
        viewModelScope.launch {
            repository.releaseSlotLock(slot.id)
        }
    }

    fun confirmEventBooking(
        service: EventService,
        dateIso: String,
        slotKey: SlotKey,
        customerName: String,
        customerPhone: String,
        venueAddress: String,
        guestCount: Long,
        payFullAmount: Boolean,
        upiApp: String,
        upiId: String,
        onBooked: (EventBooking) -> Unit
    ) {
        if (venueAddress.trim().length < 3) {
            showMessage("Please enter a valid event venue address.")
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            repository.confirmBookingWithPayment(
                service = service,
                dateIso = dateIso,
                slotKey = slotKey,
                customerName = customerName,
                customerPhone = customerPhone,
                venueAddress = venueAddress,
                guestCount = guestCount,
                payFullAmount = payFullAmount,
                upiApp = upiApp,
                upiId = upiId
            ).onSuccess { booking ->
                _lockedSlot.value = null
                showMessage("Event confirmed! Slot locked & UPI payment recorded.")
                onBooked(booking)
            }.onFailure {
                showMessage(it.localizedMessage ?: "Booking failed")
            }
            _isBusy.value = false
        }
    }

    fun payRemainingBooking(booking: EventBooking, upiApp: String, upiId: String) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.payRemainingBookingBalance(booking, upiApp, upiId)
                .onSuccess { showMessage("Remaining balance paid via $upiApp!") }
                .onFailure { showMessage(it.localizedMessage ?: "Payment failed") }
            _isBusy.value = false
        }
    }

    fun cancelBooking(booking: EventBooking, reason: String) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.cancelBooking(booking, reason)
                .onSuccess { showMessage("Booking cancelled & slot released.") }
                .onFailure { showMessage(it.localizedMessage ?: "Cancellation failed") }
            _isBusy.value = false
        }
    }

    fun toggleVendorSlotBlock(service: EventService, dateIso: String, slotKey: SlotKey, block: Boolean) {
        viewModelScope.launch {
            repository.toggleVendorSlotBlock(service, dateIso, slotKey, block)
                .onSuccess { showMessage(if (block) "Slot blocked." else "Slot marked available.") }
                .onFailure { showMessage(it.localizedMessage ?: "Failed to update slot") }
        }
    }

    // --- Cart Checkout ---

    fun checkoutCart(
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        upiApp: String,
        upiId: String,
        onSuccess: () -> Unit
    ) {
        val entries = _cart.value
        if (entries.isEmpty()) {
            showMessage("Your celebration bag is empty.")
            return
        }
        if (deliveryAddress.trim().length < 3) {
            showMessage("Please select or enter a delivery address.")
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            repository.placeProductOrders(
                cartEntries = entries,
                customerName = customerName,
                customerPhone = customerPhone,
                deliveryAddress = deliveryAddress,
                upiApp = upiApp,
                upiId = upiId
            ).onSuccess {
                clearCart()
                showMessage("Order placed successfully via $upiApp!")
                onSuccess()
            }.onFailure {
                showMessage(it.localizedMessage ?: "Checkout failed")
            }
            _isBusy.value = false
        }
    }

    fun updateOrderStatus(order: ProductOrder, nextStatus: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(order, nextStatus)
                .onSuccess { showMessage("Order updated to $nextStatus.") }
                .onFailure { showMessage(it.localizedMessage ?: "Order update failed") }
        }
    }

    // --- Vendor Registration & CRUD ---

    fun registerVendor(
        vendorName: String,
        mobileNumber: String,
        businessName: String,
        city: String,
        location: String,
        serviceCategory: String,
        documentType: String,
        documentImageBase64: String?
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.registerVendor(
                vendorName, mobileNumber, businessName, city, location,
                serviceCategory, documentType, documentImageBase64
            ).onSuccess {
                showMessage("Vendor application submitted for Admin approval!")
            }.onFailure {
                showMessage(it.localizedMessage ?: "Registration failed")
            }
            _isBusy.value = false
        }
    }

    fun saveProduct(
        vendor: Vendor,
        existingId: String?,
        name: String,
        description: String,
        category: String,
        priceInr: Long,
        stock: Long,
        imageBase64: String?,
        drawableKey: String
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.saveVendorProduct(
                vendor, existingId, name, description, category,
                priceInr, stock, imageBase64, drawableKey, active = true
            ).onSuccess {
                showMessage("Product published to marketplace!")
            }.onFailure {
                showMessage(it.localizedMessage ?: "Failed to save product")
            }
            _isBusy.value = false
        }
    }

    fun saveService(
        vendor: Vendor,
        existingId: String?,
        title: String,
        eventType: String,
        city: String,
        description: String,
        basePriceInr: Long,
        advancePercent: Long,
        drawableKey: String
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.saveVendorService(
                vendor, existingId, title, eventType, city,
                description, basePriceInr, advancePercent, drawableKey, active = true
            ).onSuccess {
                showMessage("Event package saved!")
            }.onFailure {
                showMessage(it.localizedMessage ?: "Failed to save service")
            }
            _isBusy.value = false
        }
    }

    // --- Reviews, Notifications, Complaints ---

    fun submitReview(targetType: String, targetId: String, rating: Int, comment: String) {
        viewModelScope.launch {
            repository.submitReview(
                userProfile.value?.displayName ?: currentUserName,
                targetType, targetId, rating, comment
            ).onSuccess { showMessage("Thank you for your review!") }
                .onFailure { showMessage(it.localizedMessage ?: "Review failed") }
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun submitComplaint(subject: String, description: String, referenceId: String) {
        viewModelScope.launch {
            repository.submitComplaint(
                userProfile.value?.displayName ?: currentUserName,
                subject, description, referenceId
            ).onSuccess { showMessage("Complaint submitted to Admin support.") }
                .onFailure { showMessage(it.localizedMessage ?: "Submit failed") }
        }
    }

    // --- Admin Actions ---

    fun approveOrRejectVendor(vendor: Vendor, approve: Boolean, commission: Double, reason: String?) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.approveOrRejectVendor(vendor, approve, commission, reason)
                .onSuccess { showMessage(if (approve) "Vendor approved!" else "Vendor rejected.") }
                .onFailure { showMessage(it.localizedMessage ?: "Action failed") }
            _isBusy.value = false
        }
    }

    fun updateGlobalCommission(percent: Double) {
        viewModelScope.launch {
            repository.updatePlatformCommission(percent)
                .onSuccess { showMessage("Platform commission updated to $percent%.") }
                .onFailure { showMessage(it.localizedMessage ?: "Update failed") }
        }
    }

    fun updateUserRole(userId: String, role: String) {
        viewModelScope.launch {
            repository.updateUserRole(userId, role)
                .onSuccess { showMessage("User role updated to $role.") }
                .onFailure { showMessage(it.localizedMessage ?: "Update failed") }
        }
    }

    fun toggleProductActive(productId: String, active: Boolean) {
        viewModelScope.launch {
            repository.toggleProductActive(productId, active)
                .onSuccess { showMessage(if (active) "Product enabled." else "Product hidden.") }
                .onFailure { showMessage(it.localizedMessage ?: "Update failed") }
        }
    }

    fun markRefundProcessed(payment: PaymentRecord) {
        viewModelScope.launch {
            repository.markRefundProcessed(payment)
                .onSuccess { showMessage("Refund marked complete.") }
                .onFailure { showMessage(it.localizedMessage ?: "Refund update failed") }
        }
    }

    fun resolveComplaint(id: String, status: String, note: String) {
        viewModelScope.launch {
            repository.resolveComplaint(id, status, note)
                .onSuccess { showMessage("Complaint updated.") }
                .onFailure { showMessage(it.localizedMessage ?: "Update failed") }
        }
    }

    // --- Helpers ---

    private fun <T> Flow<T>.toUiState(tag: String): StateFlow<UiState<T>> =
        map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w("MarketplaceVM", "Error observing $tag", root)
                emit(UiState.Error(root.localizedMessage ?: "Failed to load $tag"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private fun handleStreamCatch(tag: String, error: Throwable) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        Log.w("MarketplaceVM", "Stream error in $tag", firestoreError ?: error)
    }
}
