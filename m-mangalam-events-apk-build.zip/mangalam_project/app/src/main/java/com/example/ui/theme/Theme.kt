package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val MangalamDarkColorScheme = darkColorScheme(
    primary = RoyalGold,
    onPrimary = ObsidianBlack,
    primaryContainer = DeepBronze,
    onPrimaryContainer = ChampagneGold,
    secondary = WarmMarigold,
    onSecondary = ObsidianBlack,
    secondaryContainer = ElevatedCharcoal,
    onSecondaryContainer = ChampagneGold,
    tertiary = CrimsonSaffron,
    onTertiary = IvoryText,
    background = ObsidianBlack,
    onBackground = IvoryText,
    surface = VelvetSurface,
    onSurface = IvoryText,
    surfaceVariant = OnyxCard,
    onSurfaceVariant = MutedChampagne,
    outline = HairlineGoldBorder,
    outlineVariant = ElevatedCharcoal,
    error = BookedRed,
    onError = IvoryText,
    errorContainer = BookedRedBg,
    onErrorContainer = IvoryText
)

val MangalamShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MangalamTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MangalamDarkColorScheme,
        typography = AppTypography,
        shapes = MangalamShapes,
        content = content
    )
}
