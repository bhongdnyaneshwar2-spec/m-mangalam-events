package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

object MarketplaceConstants {
    val PRODUCT_CATEGORIES = listOf("Clothes", "Shoes", "Jewellery", "Gifts", "Decorations")
    val EVENT_TYPES = listOf("Wedding", "Engagement", "Birthday", "Anniversary", "Baby shower", "Party")
    val VENDOR_CATEGORIES = listOf("Wedding", "Decoration", "Photography", "Catering", "Attire & Jewellery", "Music & DJ")
    val DOCUMENT_TYPES = listOf("GST Certificate", "Shop Act License", "Aadhaar Business KYC", "PAN Card")
    val UPI_APPS = listOf("Google Pay", "PhonePe", "Paytm", "BHIM UPI")
    const val ADMIN_EMAIL = "bhongmauli4@gmail.com"
}

enum class SlotKey(val label: String, val timeRange: String) {
    MORNING("Morning Muhurat", "07:00 AM - 12:30 PM"),
    AFTERNOON("Afternoon Celebration", "01:00 PM - 05:30 PM"),
    EVENING("Royal Evening", "06:00 PM - 11:30 PM"),
    FULL_DAY("Full Day Grand", "07:00 AM - 11:30 PM");

    companion object {
        fun safeValueOf(raw: String?): SlotKey =
            entries.firstOrNull { it.name == raw } ?: EVENING
    }
}

enum class SlotStatus {
    AVAILABLE, LOCKED, PENDING, BOOKED, BLOCKED;

    companion object {
        fun safeValueOf(raw: String?): SlotStatus =
            entries.firstOrNull { it.name == raw } ?: AVAILABLE
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val role: String = "CUSTOMER",
    val preferredLanguage: String = "EN",
    val photoUrl: String? = null,
    val vendorId: String? = null,
    val vendorStatus: String = "NONE",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PrivateContact(
    @DocumentId val id: String = "",
    val userId: String = "",
    val mobileNumber: String = "",
    val mobileVerified: Boolean = false,
    val email: String? = null,
    val city: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserAddress(
    @DocumentId val id: String = "",
    val userId: String = "",
    val label: String = "Home",
    val fullName: String = "",
    val phone: String = "",
    val addressLine: String = "",
    val city: String = "",
    val pincode: String = "",
    val defaultAddress: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Vendor(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val vendorName: String = "",
    val mobileNumber: String = "",
    val businessName: String = "",
    val city: String = "",
    val location: String = "",
    val serviceCategory: String = "",
    val documentType: String = "",
    val documentImageBase64: String? = null,
    val approvalStatus: String = "PENDING",
    val rejectionReason: String? = null,
    val commissionPercent: Double = 10.0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CategoryItem(
    @DocumentId val id: String = "",
    val name: String = "",
    val kind: String = "PRODUCT",
    val commissionPercent: Double = 10.0,
    val active: Boolean = true,
    val sortOrder: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Product(
    @DocumentId val id: String = "",
    val vendorId: String = "",
    val vendorOwnerId: String = "",
    val vendorName: String = "",
    val name: String = "",
    val description: String = "",
    val category: String = "Clothes",
    val priceInr: Long = 0L,
    val stock: Long = 0L,
    val drawableKey: String = "jewellery",
    val imageBase64: String? = null,
    val active: Boolean = true,
    val ratingAvg: Double = 4.8,
    val reviewCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class EventService(
    @DocumentId val id: String = "",
    val vendorId: String = "",
    val vendorOwnerId: String = "",
    val vendorName: String = "",
    val title: String = "",
    val eventType: String = "Wedding",
    val city: String = "",
    val description: String = "",
    val basePriceInr: Long = 0L,
    val advancePercent: Long = 30L,
    val drawableKey: String = "wedding",
    val active: Boolean = true,
    val ratingAvg: Double = 4.9,
    val reviewCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AvailabilitySlot(
    @DocumentId val id: String = "",
    val serviceId: String = "",
    val vendorId: String = "",
    val vendorOwnerId: String = "",
    val dateIso: String = "",
    val slotKey: String = "EVENING",
    val status: String = "AVAILABLE",
    val lockedByUserId: String? = null,
    val lockExpiresAt: Timestamp? = null,
    val bookingId: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class EventBooking(
    @DocumentId val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val vendorId: String = "",
    val vendorOwnerId: String = "",
    val vendorName: String = "",
    val serviceId: String = "",
    val serviceTitle: String = "",
    val eventType: String = "",
    val eventDateIso: String = "",
    val slotKey: String = "",
    val slotId: String = "",
    val venueAddress: String = "",
    val guestCount: Long = 100L,
    val totalAmountInr: Long = 0L,
    val advanceAmountInr: Long = 0L,
    val paidAmountInr: Long = 0L,
    val remainingAmountInr: Long = 0L,
    val commissionRatePercent: Double = 10.0,
    val commissionAmountInr: Long = 0L,
    val vendorPayoutInr: Long = 0L,
    val status: String = "CONFIRMED",
    val paymentStatus: String = "ADVANCE_PAID",
    val cancellationReason: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class OrderItemLine(
    val productId: String = "",
    val productName: String = "",
    val category: String = "",
    val quantity: Long = 1L,
    val unitPriceInr: Long = 0L
)

@Keep
@IgnoreExtraProperties
data class ProductOrder(
    @DocumentId val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val deliveryAddress: String = "",
    val vendorId: String = "",
    val vendorOwnerId: String = "",
    val vendorName: String = "",
    val items: List<OrderItemLine> = emptyList(),
    val subtotalInr: Long = 0L,
    val commissionRatePercent: Double = 10.0,
    val commissionAmountInr: Long = 0L,
    val vendorPayoutInr: Long = 0L,
    val totalAmountInr: Long = 0L,
    val paidAmountInr: Long = 0L,
    val remainingAmountInr: Long = 0L,
    val paymentMethod: String = "UPI",
    val paymentStatus: String = "FULLY_PAID",
    val orderStatus: String = "PLACED",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PaymentRecord(
    @DocumentId val id: String = "",
    val customerId: String = "",
    val vendorId: String = "",
    val vendorOwnerId: String = "",
    val referenceType: String = "BOOKING",
    val referenceId: String = "",
    val paymentType: String = "ADVANCE",
    val amountInr: Long = 0L,
    val commissionAmountInr: Long = 0L,
    val vendorNetInr: Long = 0L,
    val upiTransactionRef: String = "",
    val upiApp: String = "Google Pay",
    val status: String = "SUCCESS",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ReviewItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val targetType: String = "PRODUCT",
    val targetId: String = "",
    val rating: Long = 5L,
    val comment: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AppNotification(
    @DocumentId val id: String = "",
    val recipientId: String = "",
    val title: String = "",
    val message: String = "",
    val type: String = "BOOKING_CONFIRMED",
    val referenceId: String = "",
    val readFlag: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ComplaintItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val subject: String = "",
    val description: String = "",
    val referenceId: String = "",
    val status: String = "OPEN",
    val adminNote: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PlatformConfig(
    @DocumentId val id: String = "",
    val defaultCommissionPercent: Double = 10.0,
    val updatedBy: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class CartEntry(
    val product: Product,
    val quantity: Int
)
