package com.example.i18n

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "mangalam_prefs")

enum class AppLanguage(val code: String, val nativeLabel: String) {
    EN("EN", "English"),
    MR("MR", "मराठी"),
    HI("HI", "हिन्दी");

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: EN
    }
}

class LanguagePreferences(private val context: Context) {
    private val langKey = stringPreferencesKey("preferred_language")

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        AppLanguage.fromCode(prefs[langKey])
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs ->
            prefs[langKey] = language.code
        }
    }
}

data class AppStrings(
    val appName: String,
    val tagline: String,
    val signInWithGoogle: String,
    val signInSubtitle: String,
    val navShop: String,
    val navEvents: String,
    val navOrders: String,
    val navVendor: String,
    val navAdmin: String,
    val navProfile: String,
    val searchProducts: String,
    val searchEvents: String,
    val allLabel: String,
    val celebrationsTitle: String,
    val featuredProductsTitle: String,
    val addToCart: String,
    val outOfStock: String,
    val inStock: String,
    val cartTitle: String,
    val checkoutTitle: String,
    val bookEventNow: String,
    val smartCalendarTitle: String,
    val selectDatePrompt: String,
    val selectSlotPrompt: String,
    val availableLabel: String,
    val bookedLabel: String,
    val pendingLabel: String,
    val blockedLabel: String,
    val lockedByYouLabel: String,
    val slotLockBanner: String,
    val payAdvance: String,
    val payFull: String,
    val payRemaining: String,
    val upiPaymentTitle: String,
    val confirmAndPay: String,
    val mobileVerificationTitle: String,
    val enterMobileNumber: String,
    val sendOtp: String,
    val enterOtp: String,
    val verifyOtp: String,
    val verifiedBadge: String,
    val addressesTitle: String,
    val addAddress: String,
    val becomeVendorTitle: String,
    val vendorDashboardTitle: String,
    val adminDashboardTitle: String,
    val notificationsTitle: String,
    val languageTitle: String,
    val signOut: String,
    val totalOrders: String,
    val totalBookings: String,
    val netEarnings: String,
    val commissionLabel: String,
    val approveLabel: String,
    val rejectLabel: String,
    val cancelBooking: String,
    val refundTracking: String,
    val complaintsTitle: String,
    val submitComplaint: String,
    val reviewsTitle: String,
    val writeReview: String,
    val emptyOrders: String,
    val emptyBookings: String,
    val emptyNotifications: String
) {
    fun productCategoryLabel(category: String): String = when (this) {
        StringsMR -> when (category) {
            "Clothes" -> "वस्त्रे"
            "Shoes" -> "पादत्राणे"
            "Jewellery" -> "दागिने"
            "Gifts" -> "भेटवस्तू"
            "Decorations" -> "सजावट"
            else -> category
        }
        StringsHI -> when (category) {
            "Clothes" -> "वस्त्र"
            "Shoes" -> "जूते"
            "Jewellery" -> "आभूषण"
            "Gifts" -> "उपहार"
            "Decorations" -> "सजावट"
            else -> category
        }
        else -> category
    }

    fun eventTypeLabel(eventType: String): String = when (this) {
        StringsMR -> when (eventType) {
            "Wedding" -> "विवाह"
            "Engagement" -> "साखरपुडा"
            "Birthday" -> "वाढदिवस"
            "Anniversary" -> "वाढदिवस / वर्धापनदिन"
            "Baby shower" -> "डोहाळे जेवण"
            "Party" -> "समारंभ पार्टी"
            else -> eventType
        }
        StringsHI -> when (eventType) {
            "Wedding" -> "विवाह"
            "Engagement" -> "सगाई"
            "Birthday" -> "जन्मदिन"
            "Anniversary" -> "सालगिरह"
            "Baby shower" -> "गोद भराई"
            "Party" -> "पार्टी"
            else -> eventType
        }
        else -> eventType
    }

    companion object {
        fun forLanguage(lang: AppLanguage): AppStrings = when (lang) {
            AppLanguage.EN -> StringsEN
            AppLanguage.MR -> StringsMR
            AppLanguage.HI -> StringsHI
        }
    }
}

val StringsEN = AppStrings(
    appName = "M Mangalam Events",
    tagline = "Every Celebration, One Place.",
    signInWithGoogle = "Sign in with Google",
    signInSubtitle = "Royal weddings, verified vendors, festive attire & seamless UPI bookings.",
    navShop = "Market",
    navEvents = "Events",
    navOrders = "Bookings",
    navVendor = "Vendor",
    navAdmin = "Admin",
    navProfile = "Profile",
    searchProducts = "Search attire, jewellery, decor...",
    searchEvents = "Search city or event package...",
    allLabel = "All",
    celebrationsTitle = "Plan a Celebration",
    featuredProductsTitle = "Celebration Marketplace",
    addToCart = "Add to Cart",
    outOfStock = "Out of Stock",
    inStock = "in stock",
    cartTitle = "Celebration Bag",
    checkoutTitle = "Checkout & UPI Payment",
    bookEventNow = "Check Calendar & Book",
    smartCalendarTitle = "Smart Availability Calendar",
    selectDatePrompt = "Tap a date to view slot availability",
    selectSlotPrompt = "Choose Event Time Slot",
    availableLabel = "Available",
    bookedLabel = "Booked",
    pendingLabel = "Pending",
    blockedLabel = "Blocked",
    lockedByYouLabel = "Locked for You",
    slotLockBanner = "Slot locked for your checkout to prevent double booking",
    payAdvance = "Pay Advance",
    payFull = "Pay Full Amount",
    payRemaining = "Pay Remaining",
    upiPaymentTitle = "UPI Checkout",
    confirmAndPay = "Confirm & Pay via UPI",
    mobileVerificationTitle = "Mobile Verification (OTP)",
    enterMobileNumber = "10-digit Mobile Number",
    sendOtp = "Send OTP",
    enterOtp = "Enter 6-digit OTP",
    verifyOtp = "Verify Mobile",
    verifiedBadge = "Verified",
    addressesTitle = "Saved Addresses",
    addAddress = "Add Address",
    becomeVendorTitle = "Vendor Registration",
    vendorDashboardTitle = "Vendor Hub",
    adminDashboardTitle = "Admin Control",
    notificationsTitle = "Notifications",
    languageTitle = "Language / भाषा",
    signOut = "Sign Out",
    totalOrders = "Total Orders",
    totalBookings = "Total Bookings",
    netEarnings = "Net Earnings",
    commissionLabel = "Marketplace Fee",
    approveLabel = "Approve",
    rejectLabel = "Reject",
    cancelBooking = "Cancel Booking",
    refundTracking = "Refund Status",
    complaintsTitle = "Support & Complaints",
    submitComplaint = "Raise Complaint",
    reviewsTitle = "Customer Reviews",
    writeReview = "Write a Review",
    emptyOrders = "No product orders placed yet.",
    emptyBookings = "No celebration bookings yet.",
    emptyNotifications = "You are all caught up!"
)

val StringsMR = AppStrings(
    appName = "एम मंगलम इव्हेंट्स",
    tagline = "प्रत्येक सोहळा, एकाच ठिकाणी.",
    signInWithGoogle = "Google सह साइन इन करा",
    signInSubtitle = "शाही विवाह, विश्वासू विक्रेते, उत्सवी पोशाख आणि सुरक्षित UPI बुकिंग.",
    navShop = "बाजार",
    navEvents = "सोहळे",
    navOrders = "बुकिंग",
    navVendor = "विक्रेता",
    navAdmin = "प्रशासन",
    navProfile = "प्रोफाइल",
    searchProducts = "कपडे, दागिने, सजावट शोधा...",
    searchEvents = "शहर किंवा सोहळा पॅकेज शोधा...",
    allLabel = "सर्व",
    celebrationsTitle = "सोहळ्याचे नियोजन करा",
    featuredProductsTitle = "उत्सव बाजारपेठ",
    addToCart = "बॅगेत टाका",
    outOfStock = "स्टॉक संपला",
    inStock = "उपलब्ध",
    cartTitle = "खरेदी बॅग",
    checkoutTitle = "चेकआउट आणि UPI पेमेंट",
    bookEventNow = "कॅलेंडर पहा आणि बुक करा",
    smartCalendarTitle = "स्मार्ट बुकिंग कॅलेंडर",
    selectDatePrompt = "उपलब्धता पाहण्यासाठी तारीख निवडा",
    selectSlotPrompt = "सोहळ्याची वेळ निवडा",
    availableLabel = "उपलब्ध",
    bookedLabel = "बुक झालेले",
    pendingLabel = "प्रलंबित",
    blockedLabel = "बंद",
    lockedByYouLabel = "तुमच्यासाठी लॉक",
    slotLockBanner = "दुहेरी बुकिंग टाळण्यासाठी ही वेळ तुमच्यासाठी लॉक केली आहे",
    payAdvance = "आगाऊ रक्कम भरा",
    payFull = "पूर्ण रक्कम भरा",
    payRemaining = "उर्वरित रक्कम भरा",
    upiPaymentTitle = "UPI पेमेंट",
    confirmAndPay = "निश्चित करा आणि UPI ने भरा",
    mobileVerificationTitle = "मोबाईल पडताळणी (OTP)",
    enterMobileNumber = "१० अंकी मोबाईल नंबर",
    sendOtp = "OTP पाठवा",
    enterOtp = "६ अंकी OTP टाका",
    verifyOtp = "पडताळणी करा",
    verifiedBadge = "पडताळलेले",
    addressesTitle = "पत्ते",
    addAddress = "नवीन पत्ता जोडा",
    becomeVendorTitle = "विक्रेता नोंदणी",
    vendorDashboardTitle = "विक्रेता डॅशबोर्ड",
    adminDashboardTitle = "प्रशासन डॅशबोर्ड",
    notificationsTitle = "सूचना",
    languageTitle = "भाषा निवडा",
    signOut = "बाहेर पडा",
    totalOrders = "एकूण ऑर्डर्स",
    totalBookings = "एकूण बुकिंग",
    netEarnings = "निव्वळ उत्पन्न",
    commissionLabel = "प्लॅटफॉर्म शुल्क",
    approveLabel = "मंजूर करा",
    rejectLabel = "नाकारा",
    cancelBooking = "बुकिंग रद्द करा",
    refundTracking = "परतावा स्थिती",
    complaintsTitle = "तक्रारी व मदत",
    submitComplaint = "तक्रार नोंदवा",
    reviewsTitle = "ग्राहकांची मते",
    writeReview = "अभिप्राय लिहा",
    emptyOrders = "अजून कोणतीही ऑर्डर नाही.",
    emptyBookings = "अजून कोणतेही सोहळा बुकिंग नाही.",
    emptyNotifications = "नवीन सूचना नाहीत!"
)

val StringsHI = AppStrings(
    appName = "एम मंगलम इवेंट्स",
    tagline = "हर उत्सव, एक ही स्थान।",
    signInWithGoogle = "Google से साइन इन करें",
    signInSubtitle = "शाही विवाह, सत्यापित विक्रेता, उत्सव परिधान और सुरक्षित UPI बुकिंग।",
    navShop = "बाज़ार",
    navEvents = "उत्सव",
    navOrders = "बुकिंग",
    navVendor = "विक्रेता",
    navAdmin = "एडमिन",
    navProfile = "प्रोफ़ाइल",
    searchProducts = "कपड़े, गहने, सजावट खोजें...",
    searchEvents = "शहर या इवेंट पैकेज खोजें...",
    allLabel = "सभी",
    celebrationsTitle = "उत्सव की योजना बनाएं",
    featuredProductsTitle = "उत्सव बाज़ार",
    addToCart = "बैग में जोड़ें",
    outOfStock = "स्टॉक समाप्त",
    inStock = "स्टॉक में",
    cartTitle = "शॉपिंग बैग",
    checkoutTitle = "चेकआउट और UPI भुगतान",
    bookEventNow = "कैलेंडर देखें और बुक करें",
    smartCalendarTitle = "स्मार्ट बुकिंग कैलेंडर",
    selectDatePrompt = "उपलब्धता देखने के लिए तारीख चुनें",
    selectSlotPrompt = "इवेंट का समय चुनें",
    availableLabel = "उपलब्ध",
    bookedLabel = "बुक हो चुका",
    pendingLabel = "लंबित",
    blockedLabel = "बंद",
    lockedByYouLabel = "आपके लिए लॉक",
    slotLockBanner = "डबल बुकिंग रोकने के लिए यह स्लॉट आपके लिए लॉक है",
    payAdvance = "अग्रिम भुगतान करें",
    payFull = "पूरी राशि दें",
    payRemaining = "शेष राशि दें",
    upiPaymentTitle = "UPI भुगतान",
    confirmAndPay = "पुष्टि करें और UPI से भुगतान करें",
    mobileVerificationTitle = "मोबाइल सत्यापन (OTP)",
    enterMobileNumber = "10 अंकों का मोबाइल नंबर",
    sendOtp = "OTP भेजें",
    enterOtp = "6 अंकों का OTP दर्ज करें",
    verifyOtp = "सत्यापित करें",
    verifiedBadge = "सत्यापित",
    addressesTitle = "सहेजे गए पते",
    addAddress = "नया पता जोड़ें",
    becomeVendorTitle = "विक्रेता पंजीकरण",
    vendorDashboardTitle = "विक्रेता डैशबोर्ड",
    adminDashboardTitle = "एडमिन डैशबोर्ड",
    notificationsTitle = "सूचनाएं",
    languageTitle = "भाषा चुनें",
    signOut = "साइन आउट",
    totalOrders = "कुल ऑर्डर",
    totalBookings = "कुल बुकिंग",
    netEarnings = "शुद्ध आय",
    commissionLabel = "मार्केटप्लेस शुल्क",
    approveLabel = "मंज़ूर करें",
    rejectLabel = "अस्वीकार करें",
    cancelBooking = "बुकिंग रद्द करें",
    refundTracking = "रिफंड स्थिति",
    complaintsTitle = "सहायता और शिकायतें",
    submitComplaint = "शिकायत दर्ज करें",
    reviewsTitle = "ग्राहक समीक्षाएं",
    writeReview = "समीक्षा लिखें",
    emptyOrders = "अभी तक कोई ऑर्डर नहीं।",
    emptyBookings = "अभी तक कोई इवेंट बुकिंग नहीं।",
    emptyNotifications = "कोई नई सूचना नहीं!"
)
