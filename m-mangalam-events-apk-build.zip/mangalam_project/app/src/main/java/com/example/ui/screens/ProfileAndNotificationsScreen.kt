package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserAddress
import com.example.i18n.AppLanguage
import com.example.i18n.AppStrings
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.StatusPill
import com.example.ui.components.mangalamFieldColors
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.BookedRed
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ElevatedCharcoal
import com.example.ui.theme.HairlineGoldBorder
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalGold
import com.example.ui.viewmodel.MarketplaceViewModel

@Composable
fun ProfileAndNotificationsScreen(
    viewModel: MarketplaceViewModel,
    strings: AppStrings,
    currentLanguage: AppLanguage,
    onSignOutClick: () -> Unit
) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val contact by viewModel.privateContact.collectAsStateWithLifecycle()
    val addresses by viewModel.addresses.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val complaints by viewModel.myComplaints.collectAsStateWithLifecycle()
    val pendingOtp by viewModel.pendingOtpCode.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    var displayName by remember(profile?.displayName) { mutableStateOf(profile?.displayName ?: viewModel.currentUserName) }
    var city by remember(contact?.city) { mutableStateOf(contact?.city ?: "") }
    var mobileInput by remember(contact?.mobileNumber) {
        mutableStateOf(contact?.mobileNumber?.takeUnless { it == "0000000000" } ?: "")
    }
    var otpInput by remember { mutableStateOf("") }
    var showAddAddressDialog by remember { mutableStateOf(false) }
    var showComplaintDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. User Profile Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OnyxCard),
                border = BorderStroke(1.dp, HairlineGoldBorder),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Customer Profile", style = MaterialTheme.typography.titleMedium, color = RoyalGold)
                        StatusPill(profile?.role ?: if (viewModel.isBootstrapAdmin) "ADMIN" else "CUSTOMER")
                    }
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Full Name") },
                        colors = mangalamFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("City / Village") },
                        colors = mangalamFieldColors(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    GoldGradientButton(
                        text = "Save Profile",
                        isLoading = isBusy,
                        onClick = { viewModel.updateProfileName(displayName, city) },
                        testTag = "save_profile_btn"
                    )
                }
            }
        }

        // 2. Mobile Number + OTP Verification
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OnyxCard),
                border = BorderStroke(1.dp, HairlineGoldBorder),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = RoyalGold)
                            Spacer(Modifier.width(8.dp))
                            Text(strings.mobileVerificationTitle, style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                        }
                        if (contact?.mobileVerified == true) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Verified, contentDescription = "Verified", tint = AvailableGreen, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.verifiedBadge, color = AvailableGreen, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = mobileInput,
                            onValueChange = { mobileInput = it.filter { ch -> ch.isDigit() }.take(12) },
                            label = { Text(strings.enterMobileNumber) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = mangalamFieldColors(),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("mobile_number_input")
                        )
                        OutlinedButton(
                            onClick = { viewModel.generateMobileOtp(mobileInput) },
                            border = BorderStroke(1.dp, RoyalGold),
                            modifier = Modifier.height(54.dp).testTag("send_otp_btn")
                        ) {
                            Text(strings.sendOtp, color = RoyalGold)
                        }
                    }

                    if (!pendingOtp.isNullOrBlank()) {
                        Surface(
                            color = ElevatedCharcoal,
                            border = BorderStroke(1.dp, RoyalGold.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Verification Code Generated: $pendingOtp",
                                style = MaterialTheme.typography.labelLarge,
                                color = ChampagneGold,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = otpInput,
                                onValueChange = { otpInput = it.filter { ch -> ch.isDigit() }.take(6) },
                                label = { Text(strings.enterOtp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = mangalamFieldColors(),
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("otp_code_input")
                            )
                            GoldGradientButton(
                                text = strings.verifyOtp,
                                onClick = { viewModel.verifyMobileOtp(otpInput) },
                                modifier = Modifier.width(130.dp),
                                testTag = "verify_otp_btn"
                            )
                        }
                    }
                }
            }
        }

        // 3. Address Management
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OnyxCard),
                border = BorderStroke(1.dp, HairlineGoldBorder),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.addressesTitle, style = MaterialTheme.typography.titleMedium, color = RoyalGold)
                        OutlinedButton(
                            onClick = { showAddAddressDialog = true },
                            border = BorderStroke(1.dp, RoyalGold),
                            modifier = Modifier.testTag("add_address_btn")
                        ) {
                            Icon(Icons.Default.AddLocationAlt, contentDescription = null, tint = RoyalGold, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.addAddress, color = RoyalGold)
                        }
                    }
                    if (addresses.isEmpty()) {
                        Text("No saved delivery or venue addresses yet.", style = MaterialTheme.typography.bodyMedium, color = MutedChampagne)
                    } else {
                        addresses.forEach { addr ->
                            Surface(
                                color = ObsidianBlack,
                                border = BorderStroke(1.dp, if (addr.defaultAddress) RoyalGold else HairlineGoldBorder),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${addr.label}${if (addr.defaultAddress) " (Default)" else ""}",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = ChampagneGold
                                        )
                                        Text("${addr.fullName} • ${addr.phone}", style = MaterialTheme.typography.labelSmall, color = IvoryText)
                                        Text("${addr.addressLine}, ${addr.city} - ${addr.pincode}", style = MaterialTheme.typography.bodyMedium, color = MutedChampagne)
                                    }
                                    IconButton(onClick = { viewModel.deleteAddress(addr.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete address", tint = BookedRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Language Switcher
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OnyxCard),
                border = BorderStroke(1.dp, HairlineGoldBorder),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.languageTitle, style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            val selected = lang == currentLanguage
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.setLanguage(lang) }
                                    .testTag("profile_lang_${lang.code}"),
                                color = if (selected) RoyalGold else ObsidianBlack,
                                border = BorderStroke(1.dp, if (selected) RoyalGold else HairlineGoldBorder),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = lang.nativeLabel,
                                    color = if (selected) ObsidianBlack else ChampagneGold,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Notifications Center
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = RoyalGold)
                Spacer(Modifier.width(8.dp))
                Text("${strings.notificationsTitle} (${notifications.size})", style = MaterialTheme.typography.titleMedium, color = RoyalGold)
            }
        }

        if (notifications.isEmpty()) {
            item {
                Text(strings.emptyNotifications, style = MaterialTheme.typography.bodyMedium, color = MutedChampagne)
            }
        } else {
            items(notifications, key = { it.id }) { notif ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { if (!notif.readFlag) viewModel.markNotificationRead(notif.id) },
                    colors = CardDefaults.cardColors(containerColor = if (notif.readFlag) OnyxCard else ElevatedCharcoal),
                    border = BorderStroke(1.dp, if (notif.readFlag) HairlineGoldBorder else RoyalGold),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(notif.title, style = MaterialTheme.typography.titleSmall, color = if (notif.readFlag) ChampagneGold else RoyalGold)
                            Text(notif.message, style = MaterialTheme.typography.bodyMedium, color = IvoryText)
                        }
                        if (!notif.readFlag) {
                            Icon(Icons.Default.MarkEmailRead, contentDescription = "Unread", tint = RoyalGold)
                        }
                    }
                }
            }
        }

        // 6. Complaints Support & Sign Out
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OnyxCard),
                border = BorderStroke(1.dp, HairlineGoldBorder),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(strings.complaintsTitle, style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                        OutlinedButton(onClick = { showComplaintDialog = true }, border = BorderStroke(1.dp, RoyalGold)) {
                            Text(strings.submitComplaint, color = RoyalGold)
                        }
                    }
                    complaints.forEach { c ->
                        Surface(color = ObsidianBlack, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(c.subject, style = MaterialTheme.typography.labelLarge, color = IvoryText)
                                    StatusPill(c.status)
                                }
                                if (!c.adminNote.isNullOrBlank()) {
                                    Text("Admin: ${c.adminNote}", style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            OutlinedButton(
                onClick = onSignOutClick,
                border = BorderStroke(1.dp, BookedRed),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("sign_out_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = BookedRed)
                Spacer(Modifier.width(8.dp))
                Text(strings.signOut, color = BookedRed, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (showAddAddressDialog) {
        AddAddressDialog(
            defaultName = displayName,
            defaultPhone = mobileInput,
            onDismiss = { showAddAddressDialog = false },
            onSave = { addr ->
                viewModel.saveAddress(addr)
                showAddAddressDialog = false
            }
        )
    }

    if (showComplaintDialog) {
        var subject by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var refId by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showComplaintDialog = false },
            containerColor = OnyxCard,
            title = { Text(strings.submitComplaint, color = RoyalGold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Subject") }, colors = mangalamFieldColors())
                    OutlinedTextField(value = refId, onValueChange = { refId = it }, label = { Text("Booking / Order ID (optional)") }, colors = mangalamFieldColors())
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Describe issue") }, colors = mangalamFieldColors())
                }
            },
            confirmButton = {
                GoldGradientButton(
                    text = "Submit",
                    enabled = subject.trim().length >= 2 && desc.trim().length >= 4,
                    onClick = {
                        viewModel.submitComplaint(subject, desc, refId)
                        showComplaintDialog = false
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { showComplaintDialog = false }) { Text("Cancel", color = MutedChampagne) }
            }
        )
    }
}

@Composable
private fun AddAddressDialog(
    defaultName: String,
    defaultPhone: String,
    onDismiss: () -> Unit,
    onSave: (UserAddress) -> Unit
) {
    var label by remember { mutableStateOf("Home") }
    var fullName by remember { mutableStateOf(defaultName) }
    var phone by remember { mutableStateOf(defaultPhone) }
    var addressLine by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var pincode by remember { mutableStateOf("") }
    var isDefault by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxCard,
        title = { Text("Add Delivery / Venue Address", color = RoyalGold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Label (Home / Mandap / Office)") }, colors = mangalamFieldColors(), singleLine = true)
                OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Contact Name") }, colors = mangalamFieldColors(), singleLine = true)
                OutlinedTextField(value = phone, onValueChange = { phone = it.filter { c -> c.isDigit() }.take(12) }, label = { Text("Phone") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), colors = mangalamFieldColors(), singleLine = true)
                OutlinedTextField(value = addressLine, onValueChange = { addressLine = it }, label = { Text("Street / Landmark") }, colors = mangalamFieldColors())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") }, colors = mangalamFieldColors(), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = pincode, onValueChange = { pincode = it.filter { c -> c.isDigit() }.take(8) }, label = { Text("PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = mangalamFieldColors(), modifier = Modifier.weight(0.8f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isDefault,
                        onCheckedChange = { isDefault = it },
                        colors = CheckboxDefaults.colors(checkedColor = RoyalGold, checkmarkColor = ObsidianBlack)
                    )
                    Text("Set as default address", color = IvoryText)
                }
            }
        },
        confirmButton = {
            val valid = fullName.trim().isNotEmpty() && phone.length >= 8 && addressLine.trim().length >= 3 && city.trim().length >= 2 && pincode.length >= 4
            GoldGradientButton(
                text = "Save Address",
                enabled = valid,
                onClick = {
                    onSave(
                        UserAddress(
                            label = label,
                            fullName = fullName,
                            phone = phone,
                            addressLine = addressLine,
                            city = city,
                            pincode = pincode,
                            defaultAddress = isDefault
                        )
                    )
                }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = MutedChampagne) }
        }
    )
}
