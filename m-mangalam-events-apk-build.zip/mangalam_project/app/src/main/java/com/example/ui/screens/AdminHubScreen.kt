package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.i18n.AppStrings
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.ProductArtwork
import com.example.ui.components.StatusPill
import com.example.ui.components.formatInr
import com.example.ui.components.mangalamFieldColors
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.BookedRed
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.HairlineGoldBorder
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MutedChampagne
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalGold
import com.example.ui.viewmodel.MarketplaceViewModel

@Composable
fun AdminHubScreen(
    viewModel: MarketplaceViewModel,
    strings: AppStrings
) {
    val vendors by viewModel.adminVendors.collectAsStateWithLifecycle()
    val users by viewModel.adminUsers.collectAsStateWithLifecycle()
    val products by viewModel.adminProducts.collectAsStateWithLifecycle()
    val bookings by viewModel.adminBookings.collectAsStateWithLifecycle()
    val payments by viewModel.adminPayments.collectAsStateWithLifecycle()
    val complaints by viewModel.adminComplaints.collectAsStateWithLifecycle()
    val config by viewModel.platformConfig.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var globalCommissionStr by remember(config.defaultCommissionPercent) {
        mutableStateOf(config.defaultCommissionPercent.toString())
    }

    val totalCommissionInr = payments.filter { it.status == "SUCCESS" }.sumOf { it.commissionAmountInr }
    val grossVolumeInr = payments.filter { it.status == "SUCCESS" }.sumOf { it.amountInr }
    val pendingVendorsCount = vendors.count { it.approvalStatus == "PENDING" }
    val openComplaintsCount = complaints.count { it.status != "RESOLVED" }

    Column(modifier = Modifier.fillMaxSize()) {
        // Admin Metrics Header
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminMetricTile("Gross GMV", formatInr(grossVolumeInr), Modifier.weight(1.2f))
            AdminMetricTile("Commission", formatInr(totalCommissionInr), Modifier.weight(1.1f))
            AdminMetricTile("Pending", "$pendingVendorsCount / $openComplaintsCount", Modifier.weight(0.9f))
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = ObsidianBlack,
            contentColor = RoyalGold,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = RoyalGold
                )
            }
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Vendors") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Finance") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Catalog") })
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Support") })
        }

        when (selectedTab) {
            0 -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(vendors, key = { it.id }) { vendor ->
                        var feeInput by remember(vendor.commissionPercent) { mutableStateOf(vendor.commissionPercent.toString()) }
                        var rejectNote by remember { mutableStateOf("") }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(vendor.businessName, style = MaterialTheme.typography.titleMedium, color = RoyalGold)
                                    StatusPill(vendor.approvalStatus)
                                }
                                Text("${vendor.vendorName} • ${vendor.mobileNumber} • ${vendor.city} (${vendor.location})", style = MaterialTheme.typography.bodyMedium, color = IvoryText)
                                Text("Category: ${vendor.serviceCategory} • Doc: ${vendor.documentType}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)

                                if (!vendor.documentImageBase64.isNullOrBlank()) {
                                    ProductArtwork(
                                        base64Image = vendor.documentImageBase64,
                                        drawableKey = "decor",
                                        contentDescription = "KYC Document",
                                        modifier = Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(10.dp))
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = feeInput,
                                        onValueChange = { feeInput = it },
                                        label = { Text("Fee %") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        colors = mangalamFieldColors(),
                                        singleLine = true,
                                        modifier = Modifier.width(96.dp)
                                    )
                                    GoldGradientButton(
                                        text = strings.approveLabel,
                                        onClick = {
                                            viewModel.approveOrRejectVendor(
                                                vendor = vendor,
                                                approve = true,
                                                commission = feeInput.toDoubleOrNull()?.coerceIn(0.0, 50.0) ?: 10.0,
                                                reason = null
                                            )
                                        },
                                        modifier = Modifier.weight(1f),
                                        testTag = "approve_vendor_${vendor.id}"
                                    )
                                    OutlinedButton(
                                        onClick = {
                                            viewModel.approveOrRejectVendor(
                                                vendor = vendor,
                                                approve = false,
                                                commission = vendor.commissionPercent,
                                                reason = rejectNote.ifBlank { "Document verification failed" }
                                            )
                                        },
                                        border = BorderStroke(1.dp, BookedRed.copy(alpha = 0.7f)),
                                        modifier = Modifier.height(50.dp)
                                    ) {
                                        Text(strings.rejectLabel, color = BookedRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, RoyalGold.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Global Marketplace Commission", style = MaterialTheme.typography.titleSmall, color = RoyalGold)
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = globalCommissionStr,
                                        onValueChange = { globalCommissionStr = it },
                                        label = { Text("Default Commission %") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        colors = mangalamFieldColors(),
                                        modifier = Modifier.weight(1f)
                                    )
                                    GoldGradientButton(
                                        text = "Save %",
                                        onClick = {
                                            globalCommissionStr.toDoubleOrNull()?.let { viewModel.updateGlobalCommission(it) }
                                        },
                                        modifier = Modifier.width(110.dp)
                                    )
                                }
                            }
                        }
                    }

                    item { Text("All UPI Payments & Refund Queue (${payments.size})", style = MaterialTheme.typography.titleSmall, color = ChampagneGold) }
                    items(payments, key = { it.id }) { pay ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${pay.referenceType} • ${pay.paymentType} • ${pay.upiApp}", style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                    StatusPill(pay.status)
                                }
                                Text("Gross: ${formatInr(pay.amountInr)} • Fee: ${formatInr(pay.commissionAmountInr)} • Vendor Net: ${formatInr(pay.vendorNetInr)}", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                                Text("Ref: ${pay.upiTransactionRef}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                if (pay.status == "REFUND_PENDING") {
                                    OutlinedButton(
                                        onClick = { viewModel.markRefundProcessed(pay) },
                                        border = BorderStroke(1.dp, AvailableGreen)
                                    ) {
                                        Text("Mark Refund Processed", color = AvailableGreen)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Text("Registered Users (${users.size})", style = MaterialTheme.typography.titleSmall, color = RoyalGold) }
                    items(users, key = { it.id }) { u ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(u.displayName, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                    Text("Lang: ${u.preferredLanguage} • Vendor: ${u.vendorStatus}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                }
                                StatusPill(u.role)
                            }
                        }
                    }

                    item { Text("Marketplace Products (${products.size})", style = MaterialTheme.typography.titleSmall, color = RoyalGold) }
                    items(products, key = { it.id }) { prod ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.name, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                    Text("${prod.vendorName} • ${formatInr(prod.priceInr)} • Stock ${prod.stock}", style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
                                }
                                OutlinedButton(
                                    onClick = { viewModel.toggleProductActive(prod.id, !prod.active) },
                                    border = BorderStroke(1.dp, if (prod.active) BookedRed else AvailableGreen)
                                ) {
                                    Text(if (prod.active) "Hide" else "Show", color = if (prod.active) BookedRed else AvailableGreen)
                                }
                            }
                        }
                    }
                }
            }
            else -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Text("All Event Bookings (${bookings.size})", style = MaterialTheme.typography.titleSmall, color = RoyalGold) }
                    items(bookings.take(15), key = { it.id }) { bkg ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${bkg.serviceTitle} (${bkg.eventDateIso})", style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                    StatusPill(bkg.status)
                                }
                                Text("${bkg.customerName} -> ${bkg.vendorName} • Fee: ${formatInr(bkg.commissionAmountInr)}", style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                            }
                        }
                    }

                    item { Text("Customer Complaints (${complaints.size})", style = MaterialTheme.typography.titleSmall, color = RoyalGold) }
                    items(complaints, key = { it.id }) { c ->
                        var note by remember(c.adminNote) { mutableStateOf(c.adminNote ?: "") }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OnyxCard),
                            border = BorderStroke(1.dp, HairlineGoldBorder),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(c.subject, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                                    StatusPill(c.status)
                                }
                                Text("${c.userName}: ${c.description}", style = MaterialTheme.typography.bodyMedium, color = MutedChampagne)
                                OutlinedTextField(
                                    value = note,
                                    onValueChange = { note = it },
                                    label = { Text("Admin Resolution Note") },
                                    colors = mangalamFieldColors(),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { viewModel.resolveComplaint(c.id, "IN_REVIEW", note) }) {
                                        Text("In Review", color = ChampagneGold)
                                    }
                                    GoldGradientButton(
                                        text = "Mark Resolved",
                                        onClick = { viewModel.resolveComplaint(c.id, "RESOLVED", note) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminMetricTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = OnyxCard),
        border = BorderStroke(1.dp, HairlineGoldBorder),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MutedChampagne)
            Spacer(Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.titleSmall, color = RoyalGold, fontWeight = FontWeight.Bold)
        }
    }
}
