# M Mangalam APK कशी बनवायची (मोबाईलवरून)

या प्रोजेक्टमध्ये GitHub Actions build workflow जोडला आहे. APK cloud मध्ये तयार होईल.


1. ZIP extract करा.
2. GitHub वर नवीन repository तयार करा (उदा. `m-mangalam-events`).
3. Extract केलेल्या सर्व फाइल्स repository मध्ये upload करा (फोल्डरची सामग्री; ZIP थेट upload नको).
4. GitHub repo उघडा → **Actions** tab → **Build M Mangalam APK** workflow निवडा.
5. **Run workflow** दाबा. Build पूर्ण होण्यासाठी काही मिनिटे लागू शकतात.
6. हिरवा success झाल्यावर workflow run उघडा. खाली **Artifacts** मध्ये `M-Mangalam-debug-apk` डाउनलोड करा.
7. ZIP उघडा; त्यातील APK Android फोनमध्ये install करा. Unknown-source installation permission Android prompt দিলে, APK install करण्यासाठी browser/file manager ला permission द्यावी लागेल.

Debug APK test/install साठी आहे; Play Store publish करण्यासाठी release signing setup വേണം.
