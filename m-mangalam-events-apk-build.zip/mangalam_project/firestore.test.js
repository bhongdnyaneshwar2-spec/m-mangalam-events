const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_cust_1";
const BOB_UID = "bob_vendor_1";
const CHARLIE_UID = "charlie_cust_2";
const ADMIN_UID = "admin_mauli_1";
const ADMIN_EMAIL = "bhongmauli4@gmail.com";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(msOffset = 2000) {
  return new Date(Date.now() - msOffset);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any collection", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("products").where("active", "==", true).get());
  await assertFails(unauth.collection("services").where("active", "==", true).get());
  await assertFails(
    unauth.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      role: "CUSTOMER",
      preferredLanguage: "EN",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
});

test("User profile creation, PII isolation, and role-escalation protection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = pastDate();

  // Self-assigned ADMIN role must fail
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      role: "ADMIN",
      preferredLanguage: "EN",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Valid CUSTOMER user profile succeeds
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Patil",
      role: "CUSTOMER",
      preferredLanguage: "MR",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Private PII contact and addresses isolated to owner
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("private")
      .doc("contact")
      .set({
        userId: ALICE_UID,
        mobileNumber: "9876543210",
        mobileVerified: true,
        email: "alice@example.com",
        city: "Pune",
        createdAt: ts,
        updatedAt: ts,
      })
  );

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("addresses")
      .doc("addr_1")
      .set({
        userId: ALICE_UID,
        label: "Home",
        fullName: "Alice Patil",
        phone: "9876543210",
        addressLine: "Kothrud Main Road",
        city: "Pune",
        pincode: "411038",
        defaultAddress: true,
        createdAt: ts,
        updatedAt: ts,
      })
  );

  // Bob cannot read Alice's profile, PII contact, or addresses
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("private").doc("contact").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("addresses").get()
  );

  // Alice cannot escalate her own role on update
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "ADMIN",
      updatedAt: pastDate(500),
    })
  );
});

test("Vendor registration, Admin approval, and Product/Service creation gates", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv
    .authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL, email_verified: true })
    .firestore();
  const ts = pastDate();

  // Vendor cannot self-approve on creation
  await assertFails(
    bobDb.collection("vendors").doc("vendor_bob").set({
      ownerId: BOB_UID,
      vendorName: "Bob Joshi",
      mobileNumber: "9123456789",
      businessName: "Royal Mandap Decor",
      city: "Nashik",
      location: "College Road",
      serviceCategory: "Wedding",
      documentType: "GST Certificate",
      approvalStatus: "APPROVED",
      commissionPercent: 10,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Valid PENDING vendor registration succeeds
  await assertSucceeds(
    bobDb.collection("vendors").doc("vendor_bob").set({
      ownerId: BOB_UID,
      vendorName: "Bob Joshi",
      mobileNumber: "9123456789",
      businessName: "Royal Mandap Decor",
      city: "Nashik",
      location: "College Road",
      serviceCategory: "Wedding",
      documentType: "GST Certificate",
      approvalStatus: "PENDING",
      commissionPercent: 10,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Pending vendor CANNOT publish a product yet
  await assertFails(
    bobDb.collection("products").doc("prod_1").set({
      vendorId: "vendor_bob",
      vendorOwnerId: BOB_UID,
      vendorName: "Royal Mandap Decor",
      name: "Brass Diya Set",
      description: "Handcrafted festive brass diyas",
      category: "Decorations",
      priceInr: 1499,
      stock: 25,
      drawableKey: "decor",
      active: true,
      ratingAvg: 4.8,
      reviewCount: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Admin approves vendor and adjusts commission
  await assertSucceeds(
    adminDb.collection("vendors").doc("vendor_bob").update({
      approvalStatus: "APPROVED",
      commissionPercent: 12,
      updatedAt: pastDate(500),
    })
  );

  // Approved vendor can now publish Product and Service
  await assertSucceeds(
    bobDb.collection("products").doc("prod_1").set({
      vendorId: "vendor_bob",
      vendorOwnerId: BOB_UID,
      vendorName: "Royal Mandap Decor",
      name: "Brass Diya Set",
      description: "Handcrafted festive brass diyas",
      category: "Decorations",
      priceInr: 1499,
      stock: 25,
      drawableKey: "decor",
      active: true,
      ratingAvg: 4.8,
      reviewCount: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    bobDb.collection("services").doc("svc_1").set({
      vendorId: "vendor_bob",
      vendorOwnerId: BOB_UID,
      vendorName: "Royal Mandap Decor",
      title: "Royal Marigold Mandap",
      eventType: "Wedding",
      city: "Nashik",
      description: "Full traditional stage and lighting setup",
      basePriceInr: 85000,
      advancePercent: 30,
      drawableKey: "wedding",
      active: true,
      ratingAvg: 4.9,
      reviewCount: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );
});

test("Smart Booking Calendar prevents double booking and enforces slot locking", async () => {
  const ts = pastDate(10000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("services").doc("svc_1").set({
      vendorId: "vendor_bob",
      vendorOwnerId: BOB_UID,
      vendorName: "Royal Mandap Decor",
      title: "Royal Marigold Mandap",
      eventType: "Wedding",
      city: "Nashik",
      description: "Full setup",
      basePriceInr: 85000,
      advancePercent: 30,
      drawableKey: "wedding",
      active: true,
      ratingAvg: 4.9,
      reviewCount: 0,
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const slotId = "svc_1_2026-12-20_EVENING";

  // Alice locks the slot for checkout
  await assertSucceeds(
    aliceDb.collection("availability").doc(slotId).set({
      serviceId: "svc_1",
      vendorId: "vendor_bob",
      vendorOwnerId: BOB_UID,
      dateIso: "2026-12-20",
      slotKey: "EVENING",
      status: "LOCKED",
      lockedByUserId: ALICE_UID,
      lockExpiresAt: new Date(Date.now() + 600000),
      createdAt: ts,
      updatedAt: pastDate(1000),
    })
  );

  // Charlie cannot hijack Alice's active lock or book the same slot
  await assertFails(
    charlieDb.collection("availability").doc(slotId).update({
      status: "BOOKED",
      lockedByUserId: CHARLIE_UID,
      bookingId: "booking_charlie",
      updatedAt: pastDate(500),
    })
  );

  // Alice confirms booking & transitions slot to BOOKED
  await assertSucceeds(
    aliceDb.collection("bookings").doc("booking_alice_1").set({
      customerId: ALICE_UID,
      customerName: "Alice Patil",
      customerPhone: "9876543210",
      vendorId: "vendor_bob",
      vendorOwnerId: BOB_UID,
      vendorName: "Royal Mandap Decor",
      serviceId: "svc_1",
      serviceTitle: "Royal Marigold Mandap",
      eventType: "Wedding",
      eventDateIso: "2026-12-20",
      slotKey: "EVENING",
      slotId,
      venueAddress: "Nashik Club Lawns",
      guestCount: 300,
      totalAmountInr: 85000,
      advanceAmountInr: 25500,
      paidAmountInr: 25500,
      remainingAmountInr: 59500,
      commissionRatePercent: 10,
      commissionAmountInr: 8500,
      vendorPayoutInr: 76500,
      status: "CONFIRMED",
      paymentStatus: "ADVANCE_PAID",
      createdAt: ts,
      updatedAt: pastDate(500),
    })
  );

  await assertSucceeds(
    aliceDb.collection("availability").doc(slotId).update({
      status: "BOOKED",
      bookingId: "booking_alice_1",
      updatedAt: pastDate(500),
    })
  );

  // Charlie CANNOT query Alice's booking, and CANNOT overwrite the BOOKED slot
  await assertFails(charlieDb.collection("bookings").doc("booking_alice_1").get());
  await assertFails(
    charlieDb.collection("availability").doc(slotId).update({
      status: "LOCKED",
      lockedByUserId: CHARLIE_UID,
      updatedAt: pastDate(100),
    })
  );

  // Matched filtered queries succeed; unfiltered bookings query fails
  await assertSucceeds(
    aliceDb.collection("bookings").where("customerId", "==", ALICE_UID).get()
  );
  await assertFails(charlieDb.collection("bookings").get());
});

test("Email spoofing with unverified email cannot obtain Admin privileges", async () => {
  const spoofedAdminDb = testEnv
    .authenticatedContext("spoof_uid", { email: ADMIN_EMAIL, email_verified: false })
    .firestore();
  await assertFails(spoofedAdminDb.collection("users").get());
});
